-- FF Small Patch Tracker — SQLite / Cloudflare D1 Schema
-- Migration: 0001_init.sql
-- Supports persistent observations, source health, signal history, duplicate prevention, and rate limiting.

CREATE TABLE IF NOT EXISTS sources_state (
  key TEXT PRIMARY KEY,
  family TEXT NOT NULL,
  label TEXT NOT NULL,
  region TEXT NOT NULL,
  is_global INTEGER NOT NULL DEFAULT 0,
  app TEXT,
  platform TEXT,
  url TEXT NOT NULL,
  poll_interval_min INTEGER NOT NULL DEFAULT 20,
  state TEXT NOT NULL DEFAULT 'pending',
  version TEXT,
  updated_date TEXT,
  file_size_bytes INTEGER,
  release_notes_hash TEXT,
  content_hash TEXT,
  latest_item_id TEXT,
  summary TEXT,
  note TEXT,
  last_checked TEXT,
  last_success TEXT,
  last_error TEXT,
  last_error_at TEXT,
  last_change_at TEXT,
  last_change TEXT,
  latency_ms INTEGER,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  raw_snapshot TEXT
);

CREATE INDEX IF NOT EXISTS idx_sources_region ON sources_state(region);
CREATE INDEX IF NOT EXISTS idx_sources_family ON sources_state(family);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  dedup_key TEXT NOT NULL UNIQUE,
  timestamp TEXT NOT NULL,
  region TEXT NOT NULL,
  app TEXT NOT NULL,
  kind TEXT NOT NULL,
  patch_type TEXT NOT NULL,
  status TEXT NOT NULL,
  classification_label TEXT NOT NULL,
  classification_reason TEXT NOT NULL,
  old_version TEXT,
  new_version TEXT,
  size TEXT,
  size_mb REAL,
  size_bucket TEXT,
  size_basis TEXT NOT NULL DEFAULT 'unavailable',
  source_key TEXT NOT NULL,
  source_family TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT NOT NULL,
  evidence TEXT NOT NULL,
  evidence_detail TEXT,
  is_global INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_events_region_time ON events(region, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_patch_type ON events(patch_type);
CREATE INDEX IF NOT EXISTS idx_events_size_bucket ON events(size_bucket);
CREATE INDEX IF NOT EXISTS idx_events_source_family ON events(source_family);

CREATE TABLE IF NOT EXISTS signal_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  region TEXT NOT NULL,
  level TEXT NOT NULL,
  classification_label TEXT NOT NULL,
  headline TEXT NOT NULL,
  reasons_json TEXT NOT NULL,
  evidence_ids_json TEXT NOT NULL,
  observed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_signal_history_region_time ON signal_history(region, observed_at DESC);

CREATE TABLE IF NOT EXISTS check_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trigger_type TEXT NOT NULL,
  started_at TEXT NOT NULL,
  completed_at TEXT,
  sources_total INTEGER NOT NULL DEFAULT 0,
  sources_ok INTEGER NOT NULL DEFAULT 0,
  sources_failed INTEGER NOT NULL DEFAULT 0,
  changes_detected INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'running',
  message TEXT
);

CREATE INDEX IF NOT EXISTS idx_check_runs_completed ON check_runs(completed_at DESC);

CREATE TABLE IF NOT EXISTS rate_limits (
  bucket_key TEXT PRIMARY KEY,
  last_request_ms INTEGER NOT NULL,
  request_count INTEGER NOT NULL DEFAULT 1,
  window_start_ms INTEGER NOT NULL
);
