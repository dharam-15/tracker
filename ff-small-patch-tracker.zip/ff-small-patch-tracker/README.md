# FF Small Patch Tracker — Recovered Full-Stack Project

Free Fire update radar and small-patch monitoring dashboard (`2–3 MB`, `5 MB`, `10 MB`, `20 MB`, and major OB updates) using strictly legitimate, publicly accessible sources.

## 1. Recovery Audit & Repaired Issues

### What Was Recovered From Uploaded Files
- `index-bdur8laz.js` (180,993 bytes): Compiled Vite + React 18.3.1 production bundle containing the UI components (`UpdateRadar`, `CheckProgressPanel`, `CurrentVersionCard`, `LatestPatchCard`, `MonitoringStatusCard`, `NotificationsCard`, `UpdateHistory`, `SourceStatus`, `WhyModal`), API client (`/api/status`, `/api/sources`, `/api/history`, `/api/notifications`, `/api/check`), and Demo Mode logic.
- `index-cggqbbae.css` (16,561 bytes): Complete dark radar stylesheet (`Chakra Petch`, `IBM Plex Sans`, `IBM Plex Mono`).
- `manifest.webmanifest`, `favicon.svg`, `icon-512.png`: Partial PWA assets.
- `netlify.toml`: Build configuration dump with broken container paths (`/opt/build/repo/dist`, `/opt/build/repo/netlify/functions`).

### What Was Missing or Broken (And Repaired)
1. **Unminified React Source Code**: Reconstructed clean, modular ES modules in `src/` (`App.jsx`, `main.jsx`, `api.js`, `signal.js`, `constants.js`, `notifications.js`, `demo.js`, `styles.css`).
2. **Missing Entry & PWA Assets**: Reconstructed `index.html`, `public/sw.js` (Service Worker for offline asset caching and browser notifications), `public/icon-192.png` (resized from `icon-512.png`), and `public/icon.svg`.
3. **Missing Backend & Database**: Built the complete backend (`backend/engine.mjs`, `backend/sources.mjs`, `backend/classifier.mjs`, `backend/local-db.mjs`, `worker/index.mjs`, `functions/api/[[route]].js`, `server/local-server.mjs`) and SQLite/D1 schema (`migrations/0001_init.sql`).
4. **Hardcoded Build Config**: Fixed `netlify.toml` (`publish = "dist"`, `command = "npm run build"`) and added `wrangler.toml` for Cloudflare Workers + D1 + Cron Triggers free-tier deployment.

## 2. Real Public Data Sources & What Each Verifies

| Source Family | Monitored Public Endpoints | Polling Interval | What It Verifies |
| :--- | :--- | :--- | :--- |
| **Apple App Store (iTunes Lookup API)** | `https://itunes.apple.com/lookup?id=1480516829&country=<cc>` (FF MAX)<br>`https://itunes.apple.com/lookup?id=1300146617&country=<cc>` (FF) | 15 min | Exact iOS `version`, `currentVersionReleaseDate`, `releaseNotes`, regional listing availability (`not_listed` vs `working`), and `fileSizeBytes` binary delta. |
| **Google Play Store Listings** | `https://play.google.com/store/apps/details?id=com.dts.freefiremax&hl=en&gl=<CC>`<br>`https://play.google.com/store/apps/details?id=com.dts.freefireth&hl=en&gl=<CC>` | 20 min | Public Android `version`, `Updated on` date, "What's new" release notes, and regional availability (e.g., `com.dts.freefireth` is `not_listed` in India while `com.dts.freefiremax` is listed). |
| **Official Garena News & Patch Notes** | `https://ff.garena.com/en/news/20/`<br>`https://ff.garena.com/id/news/` | 20 min | Official OB patch notes, small hotfix notices, maintenance windows, and stated patch sizes (e.g., `2–3 MB`, `5 MB`, `10 MB`, `20 MB`). |
| **Official YouTube Atom/RSS Feeds** | `https://www.youtube.com/feeds/videos.xml?channel_id=UC4AB0_ectRryjCF_ugD0U8w` (India)<br>`channel_id=UCM3SMB1jINy_NxH1O01z5gA` (Indonesia)<br>`channel_id=UCe5H8YhDjg_441KjjS5qrAg` (Global/TH) | 30 min | Official video announcements, patch previews, and maintenance alerts without requiring a YouTube Data API quota key. |

## 3. Signal Classification & Small-Patch Size Rules

### Signal Categories
- **CONFIRMED**: A qualifying update or release is directly verified by reliable public evidence (such as a regional store version increment `2.132.1 → 2.132.2`).
- **STRONG UPDATE SIGNAL**: Multiple independent public source families show update activity within the 72-hour window, or a regional store listing updates its release timestamp while the version number stays unchanged.
- **POSSIBLE**: Limited or indirect evidence (single announcement/video, global-only source, or minor release-note text tweak).
- **NO SIGNAL**: No qualifying change detected during the checks performed. Clearly displays the last successful check and any monitoring gap (`"No signal" does not mean an in-game update is impossible`).

### Small Patch Size Rules
- Tracks and filters `2–3 MB` (`2-3mb`), `5 MB` (`5mb`), `10 MB` (`10mb`), `20 MB` (`20mb`), and `Other size` (`other`).
- Explicitly records `size_basis`: `reported` (stated by official source), `observed` (store binary delta, with an explicit warning that binary deltas do not prove in-game small patch size), `estimated`, or `unavailable` (shown as **`Size unknown`**, never invented).

## 4. Exact Commands to Run Locally on Windows (PowerShell / CMD)

Prerequisites: **Node.js 22.5+** (recommended, includes built-in `node:sqlite`) or **Node.js 18+ with Python 3**.

```powershell
# 1. Open PowerShell in the extracted project folder
cd ff-small-patch-tracker

# 2. (Optional) Copy environment variable template
copy .env.example .env

# 3. Install dependencies (optional if using built-in offline bundler, required for Vite dev/Wrangler)
npm install

# 4. Build the production frontend into dist/
npm run build

# 5. Initialize the local SQLite database (data/tracker.sqlite) with baseline source states
npm run seed

# 6. Run the automated verification test suite
npm test

# 7. Start the local full-stack server on http://localhost:8788
npm start
```

Open `http://localhost:8788` in Chrome, Edge, or Firefox (or on your Android phone over LAN). Click **CHECK NOW** to poll all 25 public sources live and stream NDJSON progress to the radar dashboard.

## 5. GitHub Setup & Free-Tier Deployment (Cloudflare Workers + D1 + Cron)

Cloudflare Workers + D1 + Static Assets is 100% free tier with native scheduled Cron Triggers (`*/20 * * * *`) and requires **no credit card**:
- **Workers Free Quota**: 100,000 requests/day, up to 5 Cron Triggers per account.
- **D1 Free Quota**: 5 million rows read/day, 100,000 rows written/day, 5 GB total storage.
- **Fallback if Quota Reached**: Source-specific polling intervals (`15–30 min`) cache observations in D1 so public traffic reads from D1 without re-polling upstream sources. If Cron triggers are paused, you can also trigger `/api/check` from a free GitHub Actions scheduled workflow (`schedule: - cron: '*/30 * * * *'`) or manual refresh.

### Step-by-Step Deployment Commands
```powershell
# 1. Initialize Git repository and push to GitHub
git init
git add .
git commit -m "Recover FF Small Patch Tracker and implement D1 monitoring backend"
git branch -M main
git remote add origin https://github.com/<your-username>/ff-small-patch-tracker.git
git push -u origin main

# 2. Authenticate with Cloudflare
npx wrangler login

# 3. Create the free-tier Cloudflare D1 database
npx wrangler d1 create ff-patch-tracker-db
# Copy the `database_id` printed in the terminal and paste it into `wrangler.toml` under [[d1_databases]]

# 4. Apply the SQLite schema migration to remote D1
npm run cf:d1:migrate:remote

# 5. Build and deploy frontend + API Worker + 20-minute Cron Trigger
npm run cf:deploy
```
