// Cloudflare Pages Functions catch-all API route (/api/*)
import { handleApiRequest } from "../../worker/index.mjs";

export async function onRequest(context) {
  return handleApiRequest(context.request, context.env);
}
