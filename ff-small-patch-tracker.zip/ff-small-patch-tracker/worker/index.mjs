// FF Small Patch Tracker — Cloudflare Worker Entrypoint (API + Scheduled Cron Trigger + Static Assets)
import {
  getStatusForRegion,
  getSourcesList,
  getEventsHistory,
  getNotificationsSince,
  checkRateLimit,
  runMonitoringPass,
  evaluateAndStoreObservation,
  recordRegionalSignals,
  ensureSourcesRegistered
} from "../backend/engine.mjs";
import { MONITORED_SOURCES, simpleHash } from "../backend/sources.mjs";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Accept"
};

function jsonResponse(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      ...CORS_HEADERS,
      ...extraHeaders
    }
  });
}

export async function handleApiRequest(request, env) {
  const url = new URL(request.url);
  const path = url.pathname;
  const db = env.DB;

  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  if (!db) {
    return jsonResponse(
      { error: "Database binding (DB) is not configured." },
      500
    );
  }

  try {
    if (path === "/api/status" && request.method === "GET") {
      const region = url.searchParams.get("region") || "India";
      const data = await getStatusForRegion(db, region);
      return jsonResponse(data);
    }

    if (path === "/api/sources" && request.method === "GET") {
      const region = url.searchParams.get("region") || "all";
      const data = await getSourcesList(db, region);
      return jsonResponse(data);
    }

    if (path === "/api/history" && request.method === "GET") {
      const query = Object.fromEntries(url.searchParams.entries());
      const data = await getEventsHistory(db, query);
      return jsonResponse(data);
    }

    if (path === "/api/notifications" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const data = await getNotificationsSince(db, body);
      return jsonResponse(data);
    }

    if (path === "/api/diagnostics" && request.method === "GET") {
      await ensureSourcesRegistered(db);
      const runsRes = await db
        .prepare("SELECT * FROM check_runs ORDER BY id DESC LIMIT 10")
        .all();
      const sigHistRes = await db
        .prepare("SELECT * FROM signal_history ORDER BY id DESC LIMIT 15")
        .all();
      const evCountRow = await db
        .prepare("SELECT COUNT(*) AS cnt FROM events")
        .first();
      const srcCountRow = await db
        .prepare("SELECT COUNT(*) AS cnt FROM sources_state")
        .first();
      return jsonResponse({
        tables: {
          sources_state_rows: Number(srcCountRow?.cnt ?? 0),
          events_rows: Number(evCountRow?.cnt ?? 0),
          recent_check_runs: runsRes?.results || [],
          recent_signal_history: sigHistRes?.results || []
        }
      });
    }

    if (path === "/api/simulate" && request.method === "POST") {
      await ensureSourcesRegistered(db);
      const body = await request.json().catch(() => ({}));
      const region = body.region || "India";
      const scenario = body.scenario || "2-3mb";
      const nowIso = new Date().toISOString();

      let targetKey = `garena-news:global:patch-notes`;
      let obs = null;

      if (scenario === "2-3mb" || scenario === "5mb" || scenario === "10mb" || scenario === "20mb") {
        const sizeLabelMap = {
          "2-3mb": "2.6 MB",
          "5mb": "5.2 MB",
          "10mb": "10.4 MB",
          "20mb": "20.0 MB"
        };
        const mbText = sizeLabelMap[scenario];
        targetKey = region === "Indonesia" ? "garena-news:Indonesia:news" : "youtube:India:official";
        const srcDef = MONITORED_SOURCES.find((s) => s.key === targetKey) || MONITORED_SOURCES[0];
        const prevRow = await db
          .prepare("SELECT * FROM sources_state WHERE key = ?")
          .bind(srcDef.key)
          .first();
        const itemId = `sim-${scenario}-${Date.now()}`;
        const title = `Official Small Patch Notice (${region}): ${mbText} In-Game Resource Hotfix`;
        obs = {
          state: "working",
          latest_item_id: itemId,
          title,
          updated_date: nowIso.slice(0, 10),
          release_notes: `${title}. Players will download a ${mbText} small patch on login.`,
          content_hash: simpleHash(itemId),
          summary: `${title} (${nowIso.slice(0, 10)})`,
          latency_ms: 340
        };
        const res = await evaluateAndStoreObservation(db, srcDef, prevRow, obs, nowIso);
        await recordRegionalSignals(db, new Date());
        return jsonResponse({ ok: true, changed: res.changed, event: res.event });
      }

      if (scenario === "strong_metadata") {
        targetKey = `google-play:${region}:ffmax`;
        const srcDef = MONITORED_SOURCES.find((s) => s.key === targetKey);
        const prevRow = await db
          .prepare("SELECT * FROM sources_state WHERE key = ?")
          .bind(srcDef.key)
          .first();
        const newDate = nowIso.slice(0, 19).replace("T", " ");
        obs = {
          state: "working",
          version: prevRow?.version || "2.132.1",
          updated_date: newDate,
          release_notes: "Small hotfix metadata update",
          release_notes_hash: simpleHash(`meta-${newDate}`),
          summary: `v${prevRow?.version || "2.132.1"} · updated ${newDate}`,
          latency_ms: 390
        };
        const res = await evaluateAndStoreObservation(db, srcDef, prevRow, obs, nowIso);
        await recordRegionalSignals(db, new Date());
        return jsonResponse({ ok: true, changed: res.changed, event: res.event });
      }

      if (scenario === "confirmed_version") {
        targetKey = `google-play:${region}:ffmax`;
        const srcDef = MONITORED_SOURCES.find((s) => s.key === targetKey);
        const prevRow = await db
          .prepare("SELECT * FROM sources_state WHERE key = ?")
          .bind(srcDef.key)
          .first();
        const curVer = prevRow?.version || "2.132.1";
        const parts = curVer.split(".").map((n) => parseInt(n, 10) || 0);
        parts[2] = (parts[2] || 1) + 1;
        const nextVer = parts.join(".");
        obs = {
          state: "working",
          version: nextVer,
          updated_date: nowIso.slice(0, 10),
          release_notes: `Version ${nextVer} small patch (3.1 MB reported in patch notes).`,
          release_notes_hash: simpleHash(`ver-${nextVer}`),
          summary: `v${nextVer} · updated ${nowIso.slice(0, 10)}`,
          latency_ms: 410
        };
        const res = await evaluateAndStoreObservation(db, srcDef, prevRow, obs, nowIso);
        await recordRegionalSignals(db, new Date());
        return jsonResponse({ ok: true, changed: res.changed, event: res.event });
      }

      return jsonResponse({ error: "Unsupported scenario" }, 400);
    }

    if (path === "/api/check" && request.method === "POST") {
      const clientIp =
        request.headers.get("CF-Connecting-IP") ||
        request.headers.get("X-Forwarded-For") ||
        "local";
      const cooldownMs = Number(env.MANUAL_CHECK_COOLDOWN_MS || 15000);
      const rl = await checkRateLimit(db, `check:${clientIp}`, cooldownMs, 10, 600000);

      if (!rl.allowed) {
        return jsonResponse(
          {
            error: rl.reason,
            retryAfterSeconds: rl.retryAfterSeconds
          },
          429,
          { "Retry-After": String(rl.retryAfterSeconds) }
        );
      }

      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        async start(controller) {
          const send = (evt) => {
            controller.enqueue(encoder.encode(JSON.stringify(evt) + "\n"));
          };
          try {
            await runMonitoringPass(db, {
              triggerType: "manual",
              force: false,
              onProgress: send,
              customFetcher: env.CUSTOM_FETCHER || null
            });
          } catch (err) {
            send({
              type: "error",
              message: `Monitoring pass failed: ${err.message}`
            });
          } finally {
            controller.close();
          }
        }
      });

      return new Response(stream, {
        status: 200,
        headers: {
          "Content-Type": "application/x-ndjson; charset=utf-8",
          "Cache-Control": "no-store",
          ...CORS_HEADERS
        }
      });
    }

    return jsonResponse({ error: `Not found: ${path}` }, 404);
  } catch (err) {
    return jsonResponse({ error: err.message || "Internal server error" }, 500);
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      return handleApiRequest(request, env);
    }
    if (env.ASSETS && typeof env.ASSETS.fetch === "function") {
      return env.ASSETS.fetch(request);
    }
    return new Response("FF Small Patch Tracker API Worker is running.", {
      status: 200,
      headers: { "Content-Type": "text/plain; charset=utf-8" }
    });
  },

  async scheduled(event, env, ctx) {
    if (!env.DB) return;
    ctx.waitUntil(
      runMonitoringPass(env.DB, {
        triggerType: "cron",
        force: false
      })
    );
  }
};
