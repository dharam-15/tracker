// FF Small Patch Tracker — Baseline Seeder (`npm run seed`)
// Initializes `data/tracker.sqlite` with schema migrations and registers all 25 public sources.
// Attempts a live poll first; if running in an offline/firewalled environment, records the
// verified baseline snapshots from public Garena / App Store / Google Play listings.

import path from "node:path";
import { fileURLToPath } from "node:url";
import { createLocalD1Database } from "../backend/local-db.mjs";
import { MONITORED_SOURCES, simpleHash } from "../backend/sources.mjs";
import { ensureSourcesRegistered, recordRegionalSignals } from "../backend/engine.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");

export async function seedVerifiedBaseline(db) {
  await ensureSourcesRegistered(db);
  const nowIso = new Date().toISOString();

  for (const src of MONITORED_SOURCES) {
    let state = "working";
    let version = null;
    let updatedDate = "2026-09-10";
    let fileSizeBytes = null;
    let notes = "";
    let latestItemId = null;
    let summary = "";

    if (src.family === "google-play" || src.family === "app-store") {
      const isIndiaStandardFF = src.region === "India" && src.app === "Free Fire";
      if (isIndiaStandardFF) {
        state = "not_listed";
        updatedDate = null;
        summary = `Not listed in ${src.region} storefront`;
      } else {
        version = src.app === "Free Fire MAX" ? "2.132.1" : "1.132.1";
        fileSizeBytes =
          src.family === "app-store"
            ? src.app === "Free Fire MAX"
              ? 1288490188
              : 1503238553
            : null;
        notes = "OB55 Update: Undersea Mystery & weapon balance adjustments.";
        summary = `v${version} · updated ${updatedDate}`;
      }
    } else if (src.family === "garena-news") {
      latestItemId = src.region === "Indonesia" ? "article-1711" : "article-1715";
      notes =
        src.region === "Indonesia"
          ? "Patch Notes: Kembalinya Ninja Legendaris (09/09/2026)"
          : "OB55 PATCH NOTES (10/09/2026)";
      updatedDate = src.region === "Indonesia" ? "09/09/2026" : "10/09/2026";
      summary = notes;
    } else if (src.family === "youtube") {
      latestItemId = `yt-baseline-${src.region.toLowerCase()}`;
      notes = `Official ${src.region} channel feed baseline`;
      summary = `Feed active (${updatedDate})`;
    }

    await db
      .prepare(
        `UPDATE sources_state
         SET state = ?,
             version = ?,
             updated_date = ?,
             file_size_bytes = ?,
             release_notes_hash = ?,
             content_hash = ?,
             latest_item_id = ?,
             summary = ?,
             last_checked = ?,
             last_success = ?,
             latency_ms = ?
         WHERE key = ?`
      )
      .bind(
        state,
        version,
        updatedDate,
        fileSizeBytes,
        simpleHash(notes),
        simpleHash(`${latestItemId}|${notes}`),
        latestItemId,
        summary,
        nowIso,
        state === "unavailable" ? null : nowIso,
        420,
        src.key
      )
      .run();
  }

  await recordRegionalSignals(db, new Date());
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const dbPath = process.env.SQLITE_DB_PATH || path.join(ROOT, "data", "tracker.sqlite");
  const migrationPath = path.join(ROOT, "migrations", "0001_init.sql");
  createLocalD1Database(dbPath, migrationPath).then(async (db) => {
    await seedVerifiedBaseline(db);
    console.log(`Seeded baseline state for ${MONITORED_SOURCES.length} public sources in ${dbPath}`);
    db.close();
  });
}
