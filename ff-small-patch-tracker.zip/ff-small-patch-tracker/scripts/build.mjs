// FF Small Patch Tracker — Portable Production Build Script
// Uses Vite (`node_modules/.bin/vite build`) when installed, or compiles the modular
// `src/` JSX/ESM modules + bundled React 18.3.1 runtime directly into `dist/` using Babel.

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { createRequire } from "node:module";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const SRC_DIR = path.join(ROOT, "src");
const PUBLIC_DIR = path.join(ROOT, "public");
const DIST_DIR = path.join(ROOT, "dist");
const ASSETS_DIR = path.join(DIST_DIR, "assets");

function stripImportsAndExports(code) {
  let out = code;
  // Remove import statements (bundled in topological order)
  out = out.replace(/^\s*import\s+[\s\S]*?from\s+["'][^"']+["'];?\s*$/gm, "");
  out = out.replace(/^\s*import\s+["'][^"']+["'];?\s*$/gm, "");
  // Replace export default / export declarations
  out = out.replace(/export\s+default\s+function\s+([A-Za-z0-9_]+)/g, "function $1");
  out = out.replace(/export\s+(async\s+)?function\s+/g, "$1function ");
  out = out.replace(/export\s+const\s+/g, "const ");
  return out;
}

function buildWithBabelBundler() {
  fs.rmSync(DIST_DIR, { recursive: true, force: true });
  fs.mkdirSync(ASSETS_DIR, { recursive: true });

  // Copy public/ assets into dist/
  for (const file of fs.readdirSync(PUBLIC_DIR)) {
    fs.copyFileSync(path.join(PUBLIC_DIR, file), path.join(DIST_DIR, file));
  }

  // Copy styles.css into dist/assets/
  const cssContent = fs.readFileSync(path.join(SRC_DIR, "styles.css"), "utf8");
  const cssFilename = "index-cggqbbae.css";
  fs.writeFileSync(path.join(ASSETS_DIR, cssFilename), cssContent, "utf8");

  // Read vendor React 18.3.1 runtime
  const vendorReact = fs.readFileSync(path.join(__dirname, "vendor-react.js"), "utf8");

  const moduleOrder = [
    "constants.js",
    "signal.js",
    "api.js",
    "notifications.js",
    "demo.js",
    "App.jsx",
    "main.jsx"
  ];

  let combinedSrc = `
const React = window.__REACT_RUNTIME__.React;
const { useState, useEffect, useCallback, useRef, Fragment } = React;
const { createRoot } = window.__REACT_RUNTIME__.ReactDOMClient;
const API_BASE = "";
`;

  for (const modFile of moduleOrder) {
    let raw = fs.readFileSync(path.join(SRC_DIR, modFile), "utf8");
    // Replace import.meta.env reference in api.js for IIFE compatibility
    raw = raw.replace(/const API_BASE\s*=[\s\S]*?;/, "");
    combinedSrc += `\n// --- Module: ${modFile} ---\n` + stripImportsAndExports(raw) + "\n";
  }

  // Load @babel/core and @babel/plugin-transform-react-jsx
  const req = createRequire(import.meta.url);
  let babel;
  let reactJsxPlugin;
  try {
    babel = req("@babel/core");
    reactJsxPlugin = req("@babel/plugin-transform-react-jsx");
  } catch {
    babel = req("/usr/share/nodejs/@babel/core");
    reactJsxPlugin = req("/usr/share/nodejs/@babel/plugin-transform-react-jsx");
  }

  const transformed = babel.transformSync(combinedSrc, {
    filename: "App.jsx",
    babelrc: false,
    configFile: false,
    plugins: [
      [
        reactJsxPlugin,
        {
          pragma: "React.createElement",
          pragmaFrag: "React.Fragment",
          throwIfNamespace: false
        }
      ]
    ]
  });

  const jsFilename = "index-bdur8laz.js";
  const finalBundle = `${vendorReact}\n(function(){\n${transformed.code}\n})();\n`;
  fs.writeFileSync(path.join(ASSETS_DIR, jsFilename), finalBundle, "utf8");

  // Verify syntax with `node --check`
  const checkRes = spawnSync(process.execPath, ["--check", path.join(ASSETS_DIR, jsFilename)], {
    encoding: "utf8"
  });
  if (checkRes.status !== 0) {
    throw new Error(`Generated bundle syntax check failed:\n${checkRes.stderr}`);
  }

  // Generate dist/index.html
  const indexHtml = `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
    <meta name="theme-color" content="#0d0f0e" />
    <meta
      name="description"
      content="FF Small Patch Tracker — Free Fire update radar monitoring public evidence of small (2–3 MB, 5 MB, 10 MB, 20 MB) and major patches across regions."
    />
    <title>FF Small Patch Tracker — Public Update Radar</title>
    <link rel="icon" type="image/svg+xml" href="/favicon.svg" />
    <link rel="apple-touch-icon" href="/icon-192.png" />
    <link rel="manifest" href="/manifest.webmanifest" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Chakra+Petch:wght@500;600;700&family=IBM+Plex+Mono:wght@400;500;600&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" crossorigin href="/assets/${cssFilename}" />
    <script type="module" crossorigin src="/assets/${jsFilename}"></script>
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
`;
  fs.writeFileSync(path.join(DIST_DIR, "index.html"), indexHtml, "utf8");
  console.log(
    `Built production bundle in dist/ (${finalBundle.length} bytes JS, ${cssContent.length} bytes CSS).`
  );
}

const viteBin = path.join(
  ROOT,
  "node_modules",
  ".bin",
  process.platform === "win32" ? "vite.cmd" : "vite"
);

if (fs.existsSync(viteBin)) {
  console.log("Running Vite production build…");
  const res = spawnSync(viteBin, ["build"], { cwd: ROOT, stdio: "inherit", shell: true });
  if (res.status !== 0) {
    process.exit(res.status ?? 1);
  }
} else {
  buildWithBabelBundler();
}
