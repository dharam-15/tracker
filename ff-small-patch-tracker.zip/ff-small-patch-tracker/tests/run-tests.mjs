// FF Small Patch Tracker — Automated End-to-End Test Suite (`npm test`)
// Executes real tests covering all 10 required verification areas:
// 1. Project installation & production build outputs
// 2. Database schema initialization, reads, and writes
// 3. Frontend-to-backend HTTP API communication
// 4. Duplicate-event prevention (idempotent polling)
// 5. Signal classification (NO SIGNAL, POSSIBLE, STRONG UPDATE SIGNAL, CONFIRMED) & small patch sizes (2-3 MB, 5 MB, 10 MB, 20 MB, Size unknown)
// 6. Missing-source (not_listed) and API-error (unavailable) handling
// 7. Scheduled monitoring & source-specific polling interval caching
// 8. Manual refresh streaming NDJSON & rate limiting (429 Too Many Requests)
// 9. Mobile (Android) & Desktop (Windows) responsive layout rules
// 10. Deployment configuration & environment variables validation

import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createLocalD1Database } from "../backend/local-db.mjs";
import {
  extractPatchSizeInfo,
  analyzeVersionChange,
  computeDedupKey,
  classifyRegionalSignal
} from "../backend/classifier.mjs";
import {
  MONITORED_SOURCES,
  parseItunesPayload,
  parseGooglePlayHtml,
  parseGarenaNewsHtml,
  parseYoutubeFeedXml,
  simpleHash
} from "../backend/sources.mjs";
import {
  ensureSourcesRegistered,
  runMonitoringPass,
  getStatusForRegion,
  getEventsHistory
} from "../backend/engine.mjs";
import { startLocalServer } from "../server/local-server.mjs";
import { seedVerifiedBaseline } from "../scripts/seed-baseline.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");

const results = [];
async function test(name, fn) {
  const start = Date.now();
  try {
    await fn();
    const ms = Date.now() - start;
    results.push({ name, passed: true, ms });
    console.log(`✅ PASS (${ms}ms): ${name}`);
  } catch (err) {
    const ms = Date.now() - start;
    results.push({ name, passed: false, ms, error: err.message });
    console.error(`❌ FAIL (${ms}ms): ${name}\n   ${err.stack || err.message}`);
    process.exitCode = 1;
  }
}

async function runAllTests() {
  console.log("=== FF Small Patch Tracker — Automated Verification Suite ===\n");

  // 1. Production Build Verification
  await test("1. Production build artifacts exist and are valid", async () => {
    const distDir = path.join(ROOT, "dist");
    assert.ok(fs.existsSync(path.join(distDir, "index.html")), "dist/index.html must exist");
    assert.ok(fs.existsSync(path.join(distDir, "sw.js")), "dist/sw.js must exist");
    assert.ok(
      fs.existsSync(path.join(distDir, "manifest.webmanifest")),
      "dist/manifest.webmanifest must exist"
    );
    assert.ok(fs.existsSync(path.join(distDir, "icon-192.png")), "dist/icon-192.png must exist");
    assert.ok(fs.existsSync(path.join(distDir, "icon-512.png")), "dist/icon-512.png must exist");
    assert.ok(
      fs.existsSync(path.join(distDir, "assets", "index-bdur8laz.js")),
      "Compiled JS bundle must exist"
    );
    assert.ok(
      fs.existsSync(path.join(distDir, "assets", "index-cggqbbae.css")),
      "Compiled CSS bundle must exist"
    );
  });

  // 2. Small Patch Size Extraction & Version Comparison
  await test("2. Small patch size detection (2-3 MB, 5 MB, 10 MB, 20 MB, Size unknown, binary delta)", async () => {
    const p23 = extractPatchSizeInfo("Hotfix download size is 2-3 MB on startup.", null, "Garena News");
    assert.equal(p23.size_bucket, "2-3mb");
    assert.equal(p23.size_basis, "reported");

    const p5 = extractPatchSizeInfo("Mini update of 5.2 MB applied.", null, "Patch Note");
    assert.equal(p5.size_bucket, "5mb");
    assert.equal(p5.size_basis, "reported");

    const p10 = extractPatchSizeInfo("Approx. 10 MB weapon balance patch.", null, "YouTube");
    assert.equal(p10.size_bucket, "10mb");
    assert.equal(p10.size_basis, "estimated");

    const p20 = extractPatchSizeInfo("New 20 MB voice pack and event assets.", null, "Garena News");
    assert.equal(p20.size_bucket, "20mb");
    assert.equal(p20.size_basis, "reported");

    const pUnknown = extractPatchSizeInfo("Minor bug fixes and stability improvements.", null, "Google Play");
    assert.equal(pUnknown.size, null);
    assert.equal(pUnknown.size_basis, "unavailable");

    const pBinaryDelta = extractPatchSizeInfo("Bug fixes", 3 * 1024 * 1024, "App Store");
    assert.equal(pBinaryDelta.size_basis, "observed");
    assert.match(pBinaryDelta.size, /does not prove in-game patch size/);

    const smallVer = analyzeVersionChange("2.132.1", "2.132.2");
    assert.equal(smallVer.changed, true);
    assert.equal(smallVer.patch_type, "small");

    const majorVer = analyzeVersionChange("2.131.4", "2.132.0");
    assert.equal(majorVer.changed, true);
    assert.equal(majorVer.patch_type, "major");
  });

  // 3. Source Parsers Verification
  await test("3. Public source parsers (iTunes Lookup JSON, Google Play HTML, Garena News, YouTube XML)", async () => {
    const itunesEmpty = parseItunesPayload({ resultCount: 0, results: [] });
    assert.equal(itunesEmpty.state, "not_listed");

    const itunesValid = parseItunesPayload({
      resultCount: 1,
      results: [
        {
          version: "2.132.1",
          currentVersionReleaseDate: "2026-09-10T08:00:00Z",
          fileSizeBytes: "1288490188",
          releaseNotes: "Small 3 MB hotfix for Clash Squad."
        }
      ]
    });
    assert.equal(itunesValid.state, "working");
    assert.equal(itunesValid.version, "2.132.1");
    assert.equal(itunesValid.updated_date, "2026-09-10");

    const gpValid = parseGooglePlayHtml(
      '<div>Updated on</div><div>Sep 10, 2026</div><script>AF_initDataCallback({data: [[["2.132.1"]]]});</script>',
      200
    );
    assert.equal(gpValid.state, "working");
    assert.equal(gpValid.version, "2.132.1");
    assert.equal(gpValid.updated_date, "Sep 10, 2026");

    const gp404 = parseGooglePlayHtml("We're sorry, the requested URL was not found", 404);
    assert.equal(gp404.state, "not_listed");

    const gnValid = parseGarenaNewsHtml(
      '<a href="/en/article/1673/">OB54 PATCH NOTES</a><span>23/06/2026</span>'
    );
    assert.equal(gnValid.state, "working");
    assert.equal(gnValid.latest_item_id, "article-1673");

    const ytValid = parseYoutubeFeedXml(
      '<feed><entry><yt:videoId>abc123xyz</yt:videoId><title>Mini Patch 5 MB Preview</title><published>2026-10-14T10:00:00Z</published></entry></feed>'
    );
    assert.equal(ytValid.state, "working");
    assert.equal(ytValid.latest_item_id, "abc123xyz");
  });

  // Setup isolated test SQLite database
  const testDbPath = path.join(ROOT, "data", "test-tracker.sqlite");
  fs.rmSync(testDbPath, { force: true });
  const migrationPath = path.join(ROOT, "migrations", "0001_init.sql");
  const db = await createLocalD1Database(testDbPath, migrationPath);

  // 4. Database Reads/Writes & Baseline Seeding (NO SIGNAL initial state)
  await test("4. Database schema, baseline seeding, and initial NO SIGNAL state", async () => {
    await seedVerifiedBaseline(db);
    const statusIndia = await getStatusForRegion(db, "India");
    assert.equal(statusIndia.region, "India");
    assert.equal(statusIndia.signal.level, "none");
    assert.equal(statusIndia.signal.label, "NO SIGNAL");
    assert.equal(statusIndia.monitoring.state, "ok");

    // Verify Free Fire Android in India is accurately marked `not_listed`
    const ffAndroidIndia = statusIndia.versions.find(
      (v) => v.app === "Free Fire" && v.platform === "Android"
    );
    assert.ok(ffAndroidIndia);
    assert.equal(ffAndroidIndia.state, "not_listed");
  });

  // 5. Signal Classification Transitions (POSSIBLE -> STRONG UPDATE SIGNAL -> CONFIRMED) & Duplicate Prevention
  await test("5. Signal classification transitions & duplicate-event prevention", async () => {
    // Step A: Simulate single source change in India (YouTube video mentioning 5 MB mini patch) -> POSSIBLE
    const customFetcherStepA = async (src) => {
      if (src.key === "youtube:India:official") {
        return {
          state: "working",
          latest_item_id: "yt-new-patch-video-01",
          title: "Free Fire MAX 5 MB Mini Patch Balance Adjustments",
          updated_date: "2026-10-15",
          release_notes: "Free Fire MAX 5 MB Mini Patch Balance Adjustments",
          content_hash: simpleHash("yt-new-patch-video-01"),
          summary: '"Free Fire MAX 5 MB Mini Patch Balance Adjustments"'
        };
      }
      // Return unchanged baseline for other sources
      return {
        state: src.region === "India" && src.app === "Free Fire" ? "not_listed" : "working",
        version: src.app === "Free Fire MAX" ? "2.132.1" : "1.132.1",
        updated_date: "2026-09-10",
        latest_item_id: src.family === "garena-news" ? (src.region === "Indonesia" ? "article-1711" : "article-1715") : `yt-baseline-${src.region.toLowerCase()}`,
        summary: "Unchanged baseline"
      };
    };

    const runA1 = await runMonitoringPass(db, {
      triggerType: "manual",
      force: true,
      customFetcher: customFetcherStepA
    });
    assert.equal(runA1.changes, 1, "First observation of new video must create 1 event");

    const statusPossible = await getStatusForRegion(db, "India");
    assert.equal(statusPossible.signal.level, "possible");
    assert.equal(statusPossible.signal.label, "POSSIBLE");
    assert.equal(statusPossible.latestPatch.size_bucket, "5mb");
    assert.equal(statusPossible.latestPatch.size_basis, "reported");

    // Re-run with exact same data to verify duplicate prevention
    const runA2 = await runMonitoringPass(db, {
      triggerType: "manual",
      force: true,
      customFetcher: customFetcherStepA
    });
    assert.equal(runA2.changes, 0, "Duplicate polling of same observation must create 0 new events");

    // Step B: Simulate second independent source family change in India (Google Play listing date change) -> STRONG UPDATE SIGNAL
    const customFetcherStepB = async (src) => {
      if (src.key === "google-play:India:ffmax") {
        return {
          state: "working",
          version: "2.132.1",
          updated_date: "2026-10-15",
          release_notes: "Minor bug fixes",
          release_notes_hash: simpleHash("Minor bug fixes"),
          summary: "v2.132.1 · updated 2026-10-15"
        };
      }
      return customFetcherStepA(src);
    };

    const runB = await runMonitoringPass(db, {
      triggerType: "manual",
      force: true,
      customFetcher: customFetcherStepB
    });
    assert.equal(runB.changes, 1);

    const statusStrong = await getStatusForRegion(db, "India");
    assert.equal(statusStrong.signal.level, "strong");
    assert.equal(statusStrong.signal.label, "STRONG UPDATE SIGNAL");

    // Step C: Simulate store version bump in India (2.132.1 -> 2.132.2) -> CONFIRMED small patch
    const customFetcherStepC = async (src) => {
      if (src.key === "google-play:India:ffmax") {
        return {
          state: "working",
          version: "2.132.2",
          updated_date: "2026-10-15",
          release_notes: "2.8 MB hotfix patch notes.",
          release_notes_hash: simpleHash("2.8 MB hotfix patch notes."),
          summary: "v2.132.2 · updated 2026-10-15"
        };
      }
      return customFetcherStepB(src);
    };

    const runC = await runMonitoringPass(db, {
      triggerType: "manual",
      force: true,
      customFetcher: customFetcherStepC
    });
    assert.equal(runC.changes, 1);

    const statusConfirmed = await getStatusForRegion(db, "India");
    assert.equal(statusConfirmed.signal.level, "confirmed");
    assert.equal(statusConfirmed.signal.label, "CONFIRMED");
    assert.equal(statusConfirmed.latestConfirmed.new_version, "2.132.2");
    assert.equal(statusConfirmed.latestConfirmed.patch_type, "small");
    assert.equal(statusConfirmed.latestConfirmed.size_bucket, "2-3mb");
  });

  // 6. Missing-source & API-error handling
  await test("6. API-error and unavailable-source degradation handling", async () => {
    const customFetcherDegraded = async (src) => {
      if (src.key === "app-store:India:ffmax") {
        return {
          state: "unavailable",
          error: "Simulated upstream timeout (8s)",
          latency_ms: 8005
        };
      }
      return {
        state: "working",
        version: "2.132.2",
        updated_date: "2026-10-15",
        summary: "OK"
      };
    };

    const runDeg = await runMonitoringPass(db, {
      triggerType: "manual",
      force: true,
      customFetcher: customFetcherDegraded
    });
    assert.equal(runDeg.failed, 1);

    const st = await getStatusForRegion(db, "India");
    assert.equal(st.monitoring.state, "degraded");
    assert.equal(st.sources.unavailable, 1);
  });

  // 7. Scheduled monitoring & source-specific polling interval caching
  await test("7. Scheduled monitoring respects source-specific polling intervals (caching)", async () => {
    // Heal all sources first
    await seedVerifiedBaseline(db);
    let fetchCalls = 0;
    const countingFetcher = async () => {
      fetchCalls++;
      return { state: "working", version: "2.132.2", updated_date: "2026-10-15" };
    };

    // Since seedVerifiedBaseline just set `last_checked` to now, a non-forced scheduled pass should use cache
    const cachedRun = await runMonitoringPass(db, {
      triggerType: "scheduled",
      force: false,
      customFetcher: countingFetcher
    });
    assert.equal(fetchCalls, 0, "Should not re-poll sources within their polling interval");
    assert.equal(cachedRun.cached, true);
  });

  db.close();
  fs.rmSync(testDbPath, { force: true });

  // 8. Full-Stack HTTP Server, Frontend-to-Backend API & Rate Limiting
  await test("8. Full-stack HTTP API endpoints, NDJSON streaming, and 429 rate limiting", async () => {
    const serverDbPath = path.join(ROOT, "data", "test-http.sqlite");
    fs.rmSync(serverDbPath, { force: true });

    const srv = await startLocalServer({
      port: 0,
      dbPath: serverDbPath,
      manualCheckCooldownMs: 5000,
      enableScheduler: false,
      customFetcher: async (src) => ({
        state: src.region === "India" && src.app === "Free Fire" ? "not_listed" : "working",
        version: src.app === "Free Fire MAX" ? "2.132.1" : "1.132.1",
        updated_date: "2026-10-15",
        summary: "Live test response"
      })
    });

    try {
      const baseUrl = `http://127.0.0.1:${srv.port}`;

      // Verify static index.html is served
      const htmlRes = await fetch(`${baseUrl}/`);
      assert.equal(htmlRes.status, 200);
      const htmlText = await htmlRes.text();
      assert.match(htmlText, /FF Small Patch Tracker/);

      // Verify GET /api/status
      const stRes = await fetch(`${baseUrl}/api/status?region=India`);
      assert.equal(stRes.status, 200);
      const stJson = await stRes.json();
      assert.equal(stJson.region, "India");

      // Verify POST /api/check streams NDJSON and succeeds on first call
      const chk1 = await fetch(`${baseUrl}/api/check`, { method: "POST" });
      assert.equal(chk1.status, 200);
      const ndjsonText = await chk1.text();
      const lines = ndjsonText
        .trim()
        .split("\n")
        .map((l) => JSON.parse(l));
      assert.equal(lines[0].type, "start");
      assert.equal(lines[lines.length - 1].type, "complete");

      // Verify immediate second POST /api/check is rate-limited (HTTP 429)
      const chk2 = await fetch(`${baseUrl}/api/check`, { method: "POST" });
      assert.equal(chk2.status, 429, "Immediate consecutive manual check must return HTTP 429");
      const rlBody = await chk2.json();
      assert.ok(rlBody.retryAfterSeconds > 0);

      // Verify GET /api/sources
      const srcRes = await fetch(`${baseUrl}/api/sources?region=all`);
      assert.equal(srcRes.status, 200);
      const srcJson = await srcRes.json();
      assert.equal(srcJson.length, MONITORED_SOURCES.length);

      // Verify GET /api/history with filters
      const histRes = await fetch(`${baseUrl}/api/history?region=India&size=5mb`);
      assert.equal(histRes.status, 200);
      const histJson = await histRes.json();
      assert.ok(Array.isArray(histJson.events));

      // Verify POST /api/notifications
      const notifRes = await fetch(`${baseUrl}/api/notifications`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ region: "India", sinceId: 0, levels: ["strong", "confirmed"] })
      });
      assert.equal(notifRes.status, 200);
    } finally {
      await srv.close();
      fs.rmSync(serverDbPath, { force: true });
    }
  });

  // 9. Responsive CSS & Layout Rules Check
  await test("9. Responsive layout breakpoints for Android mobile and Windows desktop", async () => {
    const css = fs.readFileSync(path.join(ROOT, "src", "styles.css"), "utf8");
    assert.match(css, /@media\(max-width:900px\)/, "Tablet/laptop breakpoint must exist");
    assert.match(css, /@media\(max-width:640px\)/, "Mobile timeline breakpoint must exist");
    assert.match(css, /@media\(max-width:560px\)/, "Mobile radar scope breakpoint must exist");
  });

  // 10. Deployment Config & Environment Variables Check
  await test("10. Free-tier deployment configuration (wrangler.toml, netlify.toml, .env.example, migrations)", async () => {
    const wrangler = fs.readFileSync(path.join(ROOT, "wrangler.toml"), "utf8");
    assert.match(wrangler, /\[\[d1_databases\]\]/);
    assert.match(wrangler, /crons\s*=\s*\["\*\/20 \* \* \* \*"\]/);

    const netlify = fs.readFileSync(path.join(ROOT, "netlify.toml"), "utf8");
    assert.ok(!netlify.includes("/opt/build/repo"), "Hardcoded /opt/build/repo paths must be removed");

    const envExample = fs.readFileSync(path.join(ROOT, ".env.example"), "utf8");
    assert.match(envExample, /MANUAL_CHECK_COOLDOWN_MS=/);
  });

  const passedCount = results.filter((r) => r.passed).length;
  console.log(`\n=== Summary: ${passedCount}/${results.length} tests passed ===`);
}

runAllTests();
