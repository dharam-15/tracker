// FF Small Patch Tracker — Local Full-Stack Server (Windows / Linux / macOS)
// Serves the production build in `dist/` and all `/api/*` endpoints backed by SQLite (`data/tracker.sqlite`).

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createLocalD1Database } from "../backend/local-db.mjs";
import { handleApiRequest } from "../worker/index.mjs";
import { ensureSourcesRegistered, runMonitoringPass } from "../backend/engine.mjs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT_DIR = path.resolve(__dirname, "..");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".mjs": "application/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon"
};

export async function startLocalServer(options = {}) {
  const port = Number(options.port ?? process.env.PORT ?? 8788);
  const dbPath =
    options.dbPath ||
    process.env.SQLITE_DB_PATH ||
    path.join(ROOT_DIR, "data", "tracker.sqlite");
  const migrationPath = path.join(ROOT_DIR, "migrations", "0001_init.sql");
  const distDir = path.join(ROOT_DIR, "dist");
  const publicDir = path.join(ROOT_DIR, "public");

  const db = await createLocalD1Database(dbPath, migrationPath);
  await ensureSourcesRegistered(db);

  const env = {
    DB: db,
    MANUAL_CHECK_COOLDOWN_MS:
      options.manualCheckCooldownMs ?? process.env.MANUAL_CHECK_COOLDOWN_MS ?? "15000",
    CUSTOM_FETCHER: options.customFetcher ?? null
  };

  const server = http.createServer(async (req, res) => {
    try {
      const host = req.headers.host || `localhost:${port}`;
      const fullUrl = new URL(req.url || "/", `http://${host}`);

      if (fullUrl.pathname.startsWith("/api/")) {
        const bodyChunks = [];
        for await (const chunk of req) {
          bodyChunks.push(chunk);
        }
        const bodyBuffer = Buffer.concat(bodyChunks);

        const webReq = new Request(fullUrl.toString(), {
          method: req.method,
          headers: req.headers,
          body:
            req.method !== "GET" && req.method !== "HEAD" && bodyBuffer.length > 0
              ? bodyBuffer
              : undefined
        });

        const webRes = await handleApiRequest(webReq, env);
        res.statusCode = webRes.status;
        webRes.headers.forEach((val, key) => {
          res.setHeader(key, val);
        });

        if (webRes.body) {
          const reader = webRes.body.getReader();
          for (;;) {
            const { value, done } = await reader.read();
            if (value) res.write(Buffer.from(value));
            if (done) break;
          }
        }
        res.end();
        return;
      }

      // Serve static files from dist/ or public/
      let relPath = decodeURIComponent(fullUrl.pathname);
      if (relPath === "/") relPath = "/index.html";
      const safeRel = path.normalize(relPath).replace(/^(\.\.(\/|\\|$))+/, "");

      let filePath = path.join(distDir, safeRel);
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
        const pubCandidate = path.join(publicDir, safeRel);
        if (fs.existsSync(pubCandidate) && !fs.statSync(pubCandidate).isDirectory()) {
          filePath = pubCandidate;
        } else {
          filePath = path.join(distDir, "index.html");
        }
      }

      if (!fs.existsSync(filePath)) {
        res.statusCode = 404;
        res.end("Not found. Run `npm run build` first.");
        return;
      }

      const ext = path.extname(filePath).toLowerCase();
      res.statusCode = 200;
      res.setHeader("Content-Type", MIME_TYPES[ext] || "application/octet-stream");
      if (safeRel === "/sw.js") {
        res.setHeader("Cache-Control", "no-cache");
      }
      fs.createReadStream(filePath).pipe(res);
    } catch (err) {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify({ error: err.message }));
    }
  });

  // Optional background scheduled check loop
  let schedulerTimer = null;
  const pollMinutes = Number(process.env.POLL_INTERVAL_MINUTES || 20);
  if (options.enableScheduler ?? process.env.ENABLE_SCHEDULER !== "false") {
    schedulerTimer = setInterval(() => {
      runMonitoringPass(db, {
        triggerType: "scheduled",
        force: false,
        customFetcher: env.CUSTOM_FETCHER
      }).catch((e) => console.error("[scheduler] monitoring pass error:", e.message));
    }, pollMinutes * 60 * 1000);
    schedulerTimer.unref();
  }

  await new Promise((resolve) => server.listen(port, "127.0.0.1", resolve));

  return {
    port: server.address().port,
    db,
    server,
    close: async () => {
      if (schedulerTimer) clearInterval(schedulerTimer);
      await new Promise((resolve) => server.close(resolve));
      if (db && typeof db.close === "function") db.close();
    }
  };
}

// If invoked directly via `node server/local-server.mjs`
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  startLocalServer().then(({ port }) => {
    console.log(`FF Small Patch Tracker running at http://localhost:${port}`);
  });
}
