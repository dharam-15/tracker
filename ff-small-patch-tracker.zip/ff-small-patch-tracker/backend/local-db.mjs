// FF Small Patch Tracker — Local SQLite D1-Compatible Database Adapter
// Supports:
// 1. Node.js 22.5+ built-in `node:sqlite` (DatabaseSync) — zero external dependencies on Windows/Linux/macOS
// 2. Persistent Python 3 `sqlite3` subprocess bridge (uses OS temp workfile synced to `dbPath` so it works
//    reliably even on virtual/FUSE/network filesystems that disallow fcntl byte-range locks).

import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import readline from "node:readline";

const PYTHON_SQLITE_WORKER = `
import sys, os, json, shutil, hashlib, tempfile, sqlite3, atexit

target_path = os.path.abspath(sys.argv[1])
os.makedirs(os.path.dirname(target_path), exist_ok=True)
path_hash = hashlib.sha256(target_path.encode("utf-8")).hexdigest()[:16]
work_path = os.path.join(tempfile.gettempdir(), f"ff_tracker_{os.getpid()}_{path_hash}.sqlite")

if os.path.exists(target_path) and os.path.getsize(target_path) > 0:
    shutil.copyfile(target_path, work_path)

conn = sqlite3.connect(work_path, isolation_level=None)
conn.row_factory = sqlite3.Row

def sync_to_target():
    try:
        if os.path.exists(work_path):
            shutil.copyfile(work_path, target_path)
    except Exception:
        pass

atexit.register(sync_to_target)

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    req = json.loads(line)
    req_id = req.get("id")
    action = req.get("action")
    sql = req.get("sql", "")
    params = req.get("params", [])
    try:
        if action == "exec":
            conn.executescript(sql)
            sync_to_target()
            res = {"id": req_id, "ok": True, "result": {}}
        elif action == "all":
            cur = conn.execute(sql, params)
            rows = [dict(r) for r in cur.fetchall()]
            res = {"id": req_id, "ok": True, "result": {"results": rows}}
        elif action == "first":
            cur = conn.execute(sql, params)
            row = cur.fetchone()
            res = {"id": req_id, "ok": True, "result": dict(row) if row else None}
        elif action == "run":
            cur = conn.execute(sql, params)
            res = {"id": req_id, "ok": True, "result": {"meta": {"last_row_id": cur.lastrowid, "changes": cur.rowcount}}}
        elif action == "sync":
            sync_to_target()
            res = {"id": req_id, "ok": True, "result": {}}
        elif action == "close":
            sync_to_target()
            conn.close()
            try:
                os.remove(work_path)
            except Exception:
                pass
            res = {"id": req_id, "ok": True, "result": {}}
        else:
            res = {"id": req_id, "ok": False, "error": f"Unknown action: {action}"}
    except Exception as e:
        res = {"id": req_id, "ok": False, "error": str(e)}
    sys.stdout.write(json.dumps(res) + "\\n")
    sys.stdout.flush()
`;

class PythonSqliteBridge {
  constructor(dbPath) {
    this.dbPath = dbPath;
    this.nextId = 1;
    this.pending = new Map();
    const pyCmd = process.platform === "win32" ? "python" : "python3";
    this.proc = spawn(pyCmd, ["-u", "-c", PYTHON_SQLITE_WORKER, dbPath], {
      stdio: ["pipe", "pipe", "pipe"]
    });
    this.proc.unref();
    const rl = readline.createInterface({ input: this.proc.stdout });
    rl.on("line", (line) => {
      try {
        const msg = JSON.parse(line);
        const handler = this.pending.get(msg.id);
        if (handler) {
          this.pending.delete(msg.id);
          if (msg.ok) handler.resolve(msg.result);
          else handler.reject(new Error(msg.error));
        }
      } catch {
        // ignore non-json output
      }
    });
  }

  request(action, sql = "", params = []) {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      this.pending.set(id, { resolve, reject });
      this.proc.stdin.write(JSON.stringify({ id, action, sql, params }) + "\n");
    });
  }

  async exec(sql) {
    return this.request("exec", sql);
  }

  prepare(sql) {
    const bridge = this;
    let boundParams = [];
    const stmt = {
      bind(...args) {
        boundParams = args.map((v) => (v === undefined ? null : v));
        return stmt;
      },
      all() {
        return bridge.request("all", sql, boundParams);
      },
      first() {
        return bridge.request("first", sql, boundParams);
      },
      run() {
        return bridge.request("run", sql, boundParams);
      }
    };
    return stmt;
  }

  async close() {
    try {
      await this.request("close");
      this.proc.kill();
    } catch {
      // ignore
    }
  }
}

export async function createLocalD1Database(dbFilePath, migrationSqlPath = null) {
  fs.mkdirSync(path.dirname(dbFilePath), { recursive: true });

  let dbInstance = null;

  // 1. Try Node 22.5+ built-in `node:sqlite`
  try {
    const nodeSqlite = await import("node:sqlite");
    if (nodeSqlite && nodeSqlite.DatabaseSync) {
      const rawDb = new nodeSqlite.DatabaseSync(dbFilePath);
      dbInstance = {
        async exec(sql) {
          rawDb.exec(sql);
        },
        prepare(sql) {
          let bound = [];
          const stmt = {
            bind(...args) {
              bound = args.map((v) => (v === undefined ? null : v));
              return stmt;
            },
            async all() {
              const rows = rawDb.prepare(sql).all(...bound);
              return { results: rows };
            },
            async first() {
              const row = rawDb.prepare(sql).get(...bound);
              return row ?? null;
            },
            async run() {
              const res = rawDb.prepare(sql).run(...bound);
              return {
                meta: {
                  last_row_id: Number(res.lastInsertRowid ?? 0),
                  changes: Number(res.changes ?? 0)
                }
              };
            }
          };
          return stmt;
        },
        async close() {
          rawDb.close();
        }
      };
    }
  } catch {
    // node:sqlite not available in this Node version; fall through
  }

  // 2. Fallback to Python 3 built-in sqlite3 bridge
  if (!dbInstance) {
    dbInstance = new PythonSqliteBridge(dbFilePath);
  }

  if (migrationSqlPath && fs.existsSync(migrationSqlPath)) {
    const schemaSql = fs.readFileSync(migrationSqlPath, "utf8");
    await dbInstance.exec(schemaSql);
  }

  return dbInstance;
}
