// FF Small Patch Tracker — Core Backend Engine (Cloudflare D1 & Local SQLite compatible)
import { MONITORED_SOURCES, pollSingleSource } from "./sources.mjs";
import {
  SIGNAL_CATEGORIES,
  extractPatchSizeInfo,
  analyzeVersionChange,
  computeDedupKey,
  classifyRegionalSignal
} from "./classifier.mjs";

const VALID_REGIONS = ["India", "Bangladesh", "Indonesia", "Singapore", "Other"];
const DEFAULT_POLL_INTERVAL_MIN = 20;

/**
 * Ensure all MONITORED_SOURCES exist in `sources_state`.
 */
export async function ensureSourcesRegistered(db) {
  for (const src of MONITORED_SOURCES) {
    await db
      .prepare(
        `INSERT OR IGNORE INTO sources_state
         (key, family, label, region, is_global, app, platform, url, poll_interval_min, state, note)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`
      )
      .bind(
        src.key,
        src.family,
        src.label,
        src.region,
        src.is_global ? 1 : 0,
        src.app || null,
        src.platform || null,
        src.url,
        src.poll_interval_min || DEFAULT_POLL_INTERVAL_MIN,
        src.note || null
      )
      .run();
  }
}

/**
 * Check and update rate limit for an IP / action bucket.
 * Default manual check limit: 1 request per 15 seconds per client IP (and max 10 per 10 minutes).
 */
export async function checkRateLimit(db, bucketKey, cooldownMs = 15000, maxPerWindow = 10, windowMs = 600000) {
  const nowMs = Date.now();
  const row = await db
    .prepare("SELECT * FROM rate_limits WHERE bucket_key = ?")
    .bind(bucketKey)
    .first();

  if (!row) {
    await db
      .prepare(
        "INSERT INTO rate_limits (bucket_key, last_request_ms, request_count, window_start_ms) VALUES (?, ?, 1, ?)"
      )
      .bind(bucketKey, nowMs, nowMs)
      .run();
    return { allowed: true, retryAfterSeconds: 0 };
  }

  const elapsedSinceLast = nowMs - Number(row.last_request_ms);
  if (elapsedSinceLast < cooldownMs) {
    const retryAfterSeconds = Math.max(1, Math.ceil((cooldownMs - elapsedSinceLast) / 1000));
    return {
      allowed: false,
      retryAfterSeconds,
      reason: `Manual refresh rate limit active. Please wait ${retryAfterSeconds}s before checking again.`
    };
  }

  const elapsedWindow = nowMs - Number(row.window_start_ms);
  let newCount = Number(row.request_count) + 1;
  let newWindowStart = Number(row.window_start_ms);

  if (elapsedWindow > windowMs) {
    newCount = 1;
    newWindowStart = nowMs;
  } else if (newCount > maxPerWindow) {
    const retryAfterSeconds = Math.max(1, Math.ceil((windowMs - elapsedWindow) / 1000));
    return {
      allowed: false,
      retryAfterSeconds,
      reason: `Too many manual checks in a 10-minute window (${maxPerWindow} max). Try again in ${retryAfterSeconds}s.`
    };
  }

  await db
    .prepare(
      "UPDATE rate_limits SET last_request_ms = ?, request_count = ?, window_start_ms = ? WHERE bucket_key = ?"
    )
    .bind(nowMs, newCount, newWindowStart, bucketKey)
    .run();

  return { allowed: true, retryAfterSeconds: 0 };
}

/**
 * Record an event if its `dedup_key` has not been recorded yet.
 * Returns true if a new event was inserted, false if prevented as a duplicate.
 */
export async function insertEventIfUnique(db, eventData) {
  const dedupKey =
    eventData.dedup_key ||
    computeDedupKey({
      source_key: eventData.source_key,
      kind: eventData.kind,
      old_version: eventData.old_version,
      new_version: eventData.new_version,
      signature: eventData.signature || eventData.evidence
    });

  const existing = await db
    .prepare("SELECT id FROM events WHERE dedup_key = ?")
    .bind(dedupKey)
    .first();

  if (existing) {
    return { inserted: false, id: existing.id, dedup_key: dedupKey };
  }

  const nowIso = eventData.timestamp || new Date().toISOString();
  const detailStr =
    typeof eventData.evidence_detail === "string"
      ? eventData.evidence_detail
      : JSON.stringify(eventData.evidence_detail || {});

  const result = await db
    .prepare(
      `INSERT INTO events (
        dedup_key, timestamp, region, app, kind, patch_type, status,
        classification_label, classification_reason,
        old_version, new_version, size, size_mb, size_bucket, size_basis,
        source_key, source_family, source, source_url, evidence, evidence_detail,
        is_global, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .bind(
      dedupKey,
      nowIso,
      eventData.region,
      eventData.app || "Free Fire MAX",
      eventData.kind,
      eventData.patch_type,
      eventData.status,
      eventData.classification_label || SIGNAL_CATEGORIES[eventData.status] || "POSSIBLE",
      eventData.classification_reason || "Observed public change in monitored source.",
      eventData.old_version ?? null,
      eventData.new_version ?? null,
      eventData.size ?? null,
      eventData.size_mb ?? null,
      eventData.size_bucket ?? null,
      eventData.size_basis || "unavailable",
      eventData.source_key,
      eventData.source_family,
      eventData.source,
      eventData.source_url,
      eventData.evidence,
      detailStr,
      eventData.is_global ? 1 : 0,
      new Date().toISOString()
    )
    .run();

  return {
    inserted: true,
    id: result?.meta?.last_row_id ?? result?.lastInsertRowid ?? null,
    dedup_key: dedupKey
  };
}

/**
 * Compare a newly polled source observation against its previous snapshot in `sources_state`.
 * Detects:
 * - Version increments (major OB vs small patch)
 * - Listing date changes without version bumps (strong small-patch / pre-rollout signal)
 * - Release-notes or binary size delta changes
 * - Official Garena news / patch notes & YouTube video announcements (including stated 2-3 MB, 5 MB, 10 MB, 20 MB sizes)
 */
export async function evaluateAndStoreObservation(db, sourceDef, prevRow, obs, nowIso = new Date().toISOString()) {
  if (obs.state === "unavailable") {
    const failures = (Number(prevRow?.consecutive_failures) || 0) + 1;
    await db
      .prepare(
        `UPDATE sources_state
         SET state = 'unavailable',
             last_checked = ?,
             last_error = ?,
             last_error_at = ?,
             latency_ms = ?,
             consecutive_failures = ?
         WHERE key = ?`
      )
      .bind(
        nowIso,
        obs.error || "Source check failed",
        nowIso,
        obs.latency_ms ?? null,
        failures,
        sourceDef.key
      )
      .run();
    return { changed: false, ok: false };
  }

  // First successful baseline check for this source: store snapshot without firing a false event
  const hadBaseline =
    prevRow &&
    prevRow.last_success &&
    prevRow.state !== "pending" &&
    (prevRow.version || prevRow.updated_date || prevRow.latest_item_id || prevRow.content_hash);

  let detectedEvent = null;

  if (hadBaseline && (sourceDef.family === "google-play" || sourceDef.family === "app-store")) {
    const oldVer = prevRow.version;
    const newVer = obs.version;
    const oldDate = prevRow.updated_date;
    const newDate = obs.updated_date;
    const oldNotesHash = prevRow.release_notes_hash;
    const newNotesHash = obs.release_notes_hash;
    const oldSizeBytes = prevRow.file_size_bytes ? Number(prevRow.file_size_bytes) : null;
    const newSizeBytes = obs.file_size_bytes ? Number(obs.file_size_bytes) : null;
    const sizeDeltaBytes =
      oldSizeBytes && newSizeBytes ? newSizeBytes - oldSizeBytes : null;

    const verDiff = analyzeVersionChange(oldVer, newVer);
    const sizeInfo = extractPatchSizeInfo(obs.release_notes, sizeDeltaBytes, sourceDef.label);

    if (verDiff.changed) {
      detectedEvent = {
        timestamp: nowIso,
        region: sourceDef.region,
        app: sourceDef.app || "Free Fire MAX",
        kind: "version_change",
        patch_type: verDiff.patch_type,
        status: "confirmed",
        classification_label: SIGNAL_CATEGORIES.confirmed,
        classification_reason: `CONFIRMED: ${verDiff.reason}`,
        old_version: oldVer,
        new_version: newVer,
        size: sizeInfo.size,
        size_mb: sizeInfo.size_mb,
        size_bucket: sizeInfo.size_bucket,
        size_basis: sizeInfo.size_basis,
        source_key: sourceDef.key,
        source_family: sourceDef.family,
        source: sourceDef.label,
        source_url: sourceDef.url,
        evidence: `Listing now shows version ${newVer} (previously ${oldVer}). ${verDiff.reason}`,
        evidence_detail: {
          old_version: oldVer,
          new_version: newVer,
          old_updated_date: oldDate,
          new_updated_date: newDate,
          file_size_delta_bytes: sizeDeltaBytes,
          release_notes_excerpt: (obs.release_notes || "").slice(0, 300)
        },
        is_global: sourceDef.is_global,
        signature: `${oldVer}->${newVer}`
      };
    } else if (oldDate && newDate && oldDate !== newDate) {
      detectedEvent = {
        timestamp: nowIso,
        region: sourceDef.region,
        app: sourceDef.app || "Free Fire MAX",
        kind: "listing_change",
        patch_type: sizeInfo.size_bucket ? "small" : "listing",
        status: "strong",
        classification_label: SIGNAL_CATEGORIES.strong,
        classification_reason:
          "STRONG UPDATE SIGNAL: Store listing updated_date changed while version remained unchanged, which often accompanies a server/resource hotfix or staged rollout.",
        old_version: oldVer,
        new_version: newVer,
        size: sizeInfo.size,
        size_mb: sizeInfo.size_mb,
        size_bucket: sizeInfo.size_bucket,
        size_basis: sizeInfo.size_basis,
        source_key: sourceDef.key,
        source_family: sourceDef.family,
        source: sourceDef.label,
        source_url: sourceDef.url,
        evidence: `Listing date changed from ${oldDate} to ${newDate} while the version stayed ${
          newVer ?? "unchanged"
        }.`,
        evidence_detail: {
          version: newVer,
          old_updated_date: oldDate,
          new_updated_date: newDate,
          file_size_delta_bytes: sizeDeltaBytes
        },
        is_global: sourceDef.is_global,
        signature: `date:${oldDate}->${newDate}:${newVer}`
      };
    } else if (oldNotesHash && newNotesHash && oldNotesHash !== newNotesHash) {
      detectedEvent = {
        timestamp: nowIso,
        region: sourceDef.region,
        app: sourceDef.app || "Free Fire MAX",
        kind: "listing_change",
        patch_type: sizeInfo.size_bucket ? "small" : "listing",
        status: "possible",
        classification_label: SIGNAL_CATEGORIES.possible,
        classification_reason:
          "POSSIBLE: Store release-notes text changed without a version number increment.",
        old_version: oldVer,
        new_version: newVer,
        size: sizeInfo.size,
        size_mb: sizeInfo.size_mb,
        size_bucket: sizeInfo.size_bucket,
        size_basis: sizeInfo.size_basis,
        source_key: sourceDef.key,
        source_family: sourceDef.family,
        source: sourceDef.label,
        source_url: sourceDef.url,
        evidence: `Release-notes text changed while version remained ${newVer ?? "unchanged"}${
          sizeInfo.size ? ` (${sizeInfo.size})` : ""
        }.`,
        evidence_detail: {
          version: newVer,
          old_notes_hash: oldNotesHash,
          new_notes_hash: newNotesHash,
          release_notes_excerpt: (obs.release_notes || "").slice(0, 300)
        },
        is_global: sourceDef.is_global,
        signature: `notes:${newNotesHash}:${newVer}`
      };
    }
  } else if (
    hadBaseline &&
    (sourceDef.family === "garena-news" || sourceDef.family === "youtube")
  ) {
    const oldItemId = prevRow.latest_item_id;
    const newItemId = obs.latest_item_id;
    if (oldItemId && newItemId && oldItemId !== newItemId) {
      const text = obs.release_notes || obs.title || "";
      const sizeInfo = extractPatchSizeInfo(text, null, sourceDef.label);
      const isMaintenance = /maintenance|server down|downtime/i.test(text);
      const isSmallPatch =
        Boolean(sizeInfo.size_bucket && sizeInfo.size_bucket !== "other") ||
        /small patch|hotfix|mini update|bug fix|weapon adjustment|balance/i.test(text);
      const isMajorOb = /\bOB\d{2}\b/i.test(text);

      const patchType = isMaintenance
        ? "maintenance"
        : isSmallPatch
        ? "small"
        : isMajorOb
        ? "major"
        : "announcement";

      detectedEvent = {
        timestamp: nowIso,
        region: sourceDef.region,
        app: sourceDef.app || "Free Fire MAX",
        kind: sourceDef.family === "youtube" ? "official_video" : "official_post",
        patch_type: patchType,
        status: "possible",
        classification_label: SIGNAL_CATEGORIES.possible,
        classification_reason: `POSSIBLE: New ${
          sourceDef.family === "youtube" ? "official video" : "official Garena post"
        } detected. Kept as POSSIBLE until corroborated by a second source family or store version bump.`,
        old_version: null,
        new_version: null,
        size: sizeInfo.size,
        size_mb: sizeInfo.size_mb,
        size_bucket: sizeInfo.size_bucket,
        size_basis: sizeInfo.size_basis,
        source_key: sourceDef.key,
        source_family: sourceDef.family,
        source: sourceDef.label,
        source_url: sourceDef.url,
        evidence: `New ${
          sourceDef.family === "youtube" ? "official video" : "official post"
        } "${obs.title || "Update notice"}" appeared${
          sizeInfo.size ? ` mentioning ${sizeInfo.size}` : ""
        }.`,
        evidence_detail: {
          previous_item_id: oldItemId,
          new_item_id: newItemId,
          title: obs.title,
          updated_date: obs.updated_date
        },
        is_global: sourceDef.is_global,
        signature: `item:${newItemId}`
      };
    }
  }

  let changeInserted = false;
  let changeSummary = prevRow?.last_change ?? null;
  let changeAt = prevRow?.last_change_at ?? null;

  if (detectedEvent) {
    const ins = await insertEventIfUnique(db, detectedEvent);
    if (ins.inserted) {
      changeInserted = true;
      changeSummary = detectedEvent.evidence;
      changeAt = nowIso;
    }
  }

  await db
    .prepare(
      `UPDATE sources_state
       SET state = ?,
           version = COALESCE(?, version),
           updated_date = COALESCE(?, updated_date),
           file_size_bytes = COALESCE(?, file_size_bytes),
           release_notes_hash = COALESCE(?, release_notes_hash),
           content_hash = COALESCE(?, content_hash),
           latest_item_id = COALESCE(?, latest_item_id),
           summary = ?,
           last_checked = ?,
           last_success = ?,
           last_error = NULL,
           last_error_at = NULL,
           last_change_at = ?,
           last_change = ?,
           latency_ms = ?,
           consecutive_failures = 0,
           raw_snapshot = ?
       WHERE key = ?`
    )
    .bind(
      obs.state,
      obs.version ?? null,
      obs.updated_date ?? null,
      obs.file_size_bytes ?? null,
      obs.release_notes_hash ?? null,
      obs.content_hash ?? null,
      obs.latest_item_id ?? null,
      obs.summary ?? null,
      nowIso,
      nowIso,
      changeAt,
      changeSummary,
      obs.latency_ms ?? null,
      JSON.stringify(obs),
      sourceDef.key
    )
    .run();

  return { changed: changeInserted, ok: true, event: detectedEvent };
}

/**
 * Record current signal evaluations per region in `signal_history`.
 */
export async function recordRegionalSignals(db, now = new Date()) {
  const cutoffIso = new Date(now.getTime() - 72 * 3600 * 1000).toISOString();
  const recentRes = await db
    .prepare("SELECT * FROM events WHERE timestamp >= ? ORDER BY timestamp DESC")
    .bind(cutoffIso)
    .all();
  const recentEvents = recentRes?.results || [];

  for (const region of VALID_REGIONS) {
    const sig = classifyRegionalSignal(region, recentEvents, now);
    await db
      .prepare(
        `INSERT INTO signal_history
         (region, level, classification_label, headline, reasons_json, evidence_ids_json, observed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .bind(
        region,
        sig.level,
        sig.label,
        sig.headline,
        JSON.stringify(sig.reasons),
        JSON.stringify(sig.evidence.map((e) => e.id)),
        now.toISOString()
      )
      .run();
  }
}

/**
 * Execute a full monitoring pass across all registered sources.
 * Honors source-specific polling intervals unless `force = true`.
 */
export async function runMonitoringPass(db, options = {}) {
  const {
    triggerType = "scheduled",
    force = false,
    onProgress = () => {},
    customFetcher = null
  } = options;

  await ensureSourcesRegistered(db);
  const startedIso = new Date().toISOString();

  const runInsert = await db
    .prepare(
      "INSERT INTO check_runs (trigger_type, started_at, sources_total, status, message) VALUES (?, ?, ?, 'running', 'Checking sources…')"
    )
    .bind(triggerType, startedIso, MONITORED_SOURCES.length)
    .run();
  const runId = runInsert?.meta?.last_row_id ?? runInsert?.lastInsertRowid ?? null;

  onProgress({
    type: "start",
    total: MONITORED_SOURCES.length,
    message: `Checking ${MONITORED_SOURCES.length} public sources…`
  });

  let okCount = 0;
  let failedCount = 0;
  let changesCount = 0;
  let cachedCount = 0;

  for (let i = 0; i < MONITORED_SOURCES.length; i++) {
    const srcDef = MONITORED_SOURCES[i];
    const prevRow = await db
      .prepare("SELECT * FROM sources_state WHERE key = ?")
      .bind(srcDef.key)
      .first();

    const nowMs = Date.now();
    const pollIntervalMs = (srcDef.poll_interval_min || DEFAULT_POLL_INTERVAL_MIN) * 60 * 1000;
    const lastCheckedMs = prevRow?.last_checked ? new Date(prevRow.last_checked).getTime() : 0;

    // Use cached state if checked recently within source's specific interval and not forced
    if (
      !force &&
      prevRow &&
      prevRow.state !== "pending" &&
      prevRow.state !== "unavailable" &&
      nowMs - lastCheckedMs < pollIntervalMs
    ) {
      okCount++;
      cachedCount++;
      onProgress({
        type: "source",
        index: i + 1,
        total: MONITORED_SOURCES.length,
        key: srcDef.key,
        label: srcDef.label,
        state: prevRow.state,
        cached: true,
        message: `Source ${i + 1}/${MONITORED_SOURCES.length}: ${srcDef.label} — ${prevRow.state} (cached within ${srcDef.poll_interval_min}m interval)`
      });
      continue;
    }

    const obs = await pollSingleSource(srcDef, customFetcher);
    const evalRes = await evaluateAndStoreObservation(
      db,
      srcDef,
      prevRow,
      obs,
      new Date().toISOString()
    );

    if (evalRes.ok) {
      okCount++;
      if (evalRes.changed) changesCount++;
    } else {
      failedCount++;
    }

    onProgress({
      type: "source",
      index: i + 1,
      total: MONITORED_SOURCES.length,
      key: srcDef.key,
      label: srcDef.label,
      state: obs.state,
      message: `Checking source ${i + 1}/${MONITORED_SOURCES.length}: ${srcDef.label} — ${obs.state}`
    });
  }

  onProgress({
    type: "compare",
    message: "Evaluating regional signals and recording signal history…"
  });

  await recordRegionalSignals(db, new Date());

  const completedIso = new Date().toISOString();
  const summaryMessage = `Check complete: ${okCount} sources healthy (${cachedCount} cached), ${failedCount} unavailable, ${changesCount} new change${
    changesCount === 1 ? "" : "s"
  } detected.`;

  if (runId) {
    await db
      .prepare(
        `UPDATE check_runs
         SET completed_at = ?, sources_ok = ?, sources_failed = ?, changes_detected = ?, status = 'complete', message = ?
         WHERE id = ?`
      )
      .bind(completedIso, okCount, failedCount, changesCount, summaryMessage, runId)
      .run();
  }

  const finalEvent = {
    type: "complete",
    changes: changesCount,
    ok: okCount,
    failed: failedCount,
    cached: cachedCount > 0,
    message: summaryMessage
  };
  onProgress(finalEvent);
  return finalEvent;
}

/**
 * Build the response for `GET /api/status?region=<region>`
 */
export async function getStatusForRegion(db, regionParam = "India") {
  await ensureSourcesRegistered(db);
  const region = VALID_REGIONS.includes(regionParam) ? regionParam : "India";

  const sourcesRes = await db
    .prepare("SELECT * FROM sources_state WHERE region = ? OR is_global = 1")
    .bind(region)
    .all();
  const sources = sourcesRes?.results || [];

  const cutoffIso = new Date(Date.now() - 72 * 3600 * 1000).toISOString();
  const eventsRes = await db
    .prepare(
      "SELECT * FROM events WHERE (region = ? OR is_global = 1) AND timestamp >= ? ORDER BY timestamp DESC"
    )
    .bind(region, cutoffIso)
    .all();
  const recentEvents = (eventsRes?.results || []).map(normalizeEventRow);

  const allRegionalEventsRes = await db
    .prepare("SELECT * FROM events WHERE region = ? ORDER BY timestamp DESC LIMIT 25")
    .bind(region)
    .all();
  const allRegionalEvents = (allRegionalEventsRes?.results || []).map(normalizeEventRow);

  const signal = classifyRegionalSignal(region, recentEvents, new Date(), 72);
  const latestPatch = allRegionalEvents[0] ?? null;
  const latestConfirmed =
    allRegionalEvents.find((e) => e.status === "confirmed" && e.kind === "version_change") ??
    null;

  // Extract regional store versions for Free Fire & Free Fire MAX
  const storeSources = sources.filter(
    (s) => s.region === region && (s.family === "google-play" || s.family === "app-store")
  );
  const versions = storeSources.map((s) => ({
    app: s.app || "Free Fire MAX",
    platform: s.platform || (s.family === "google-play" ? "Android" : "iOS"),
    version: s.version || null,
    updated: s.updated_date || null,
    state: s.state || "pending",
    source_url: s.url,
    observed_at: s.last_success || s.last_checked || null
  }));

  // Compute last check and monitoring health
  const checkedTimes = sources
    .map((s) => s.last_checked)
    .filter(Boolean)
    .sort((a, b) => b.localeCompare(a));
  const lastCheck = checkedTimes[0] ?? null;
  const nextCheck = lastCheck
    ? new Date(new Date(lastCheck).getTime() + DEFAULT_POLL_INTERVAL_MIN * 60 * 1000).toISOString()
    : null;

  const counts = {
    total: sources.length,
    working: sources.filter((s) => s.state === "working").length,
    slow: sources.filter((s) => s.state === "slow").length,
    unavailable: sources.filter((s) => s.state === "unavailable").length,
    not_listed: sources.filter((s) => s.state === "not_listed").length,
    pending: sources.filter((s) => s.state === "pending").length
  };

  let monState = "ok";
  let monMessage = "All monitored public sources for this region are responding normally.";
  let gapMinutes = null;

  if (lastCheck) {
    gapMinutes = Math.max(0, Math.round((Date.now() - new Date(lastCheck).getTime()) / 60000));
  }

  if (!lastCheck || counts.pending === counts.total) {
    monState = "never";
    monMessage =
      "Waiting for first monitoring check. Click CHECK NOW to poll public sources and establish a baseline.";
  } else if (counts.working + counts.slow + counts.not_listed === 0) {
    monState = "unavailable";
    monMessage = "All public sources for this region failed to respond on the latest check.";
  } else if (counts.unavailable > 0) {
    monState = "degraded";
    monMessage = `${counts.unavailable} of ${counts.total} monitored sources failed on the last check; remaining sources are active.`;
  } else if (gapMinutes !== null && gapMinutes > DEFAULT_POLL_INTERVAL_MIN * 2) {
    monMessage = `Last check was ${gapMinutes} min ago (monitoring gap exceeds scheduled ${DEFAULT_POLL_INTERVAL_MIN} min interval).`;
  }

  return {
    mode: "REAL MONITORING",
    region,
    generatedAt: new Date().toISOString(),
    signal,
    latestPatch,
    latestConfirmed,
    versions,
    lastCheck,
    nextCheck,
    intervalMinutes: DEFAULT_POLL_INTERVAL_MIN,
    monitoring: {
      state: monState,
      gapMinutes,
      message: monMessage
    },
    sources: counts
  };
}

/**
 * Build the response for `GET /api/sources?region=<region>`
 */
export async function getSourcesList(db, regionParam = "all") {
  await ensureSourcesRegistered(db);
  let rows;
  if (regionParam && regionParam !== "all" && VALID_REGIONS.includes(regionParam)) {
    const res = await db
      .prepare(
        "SELECT * FROM sources_state WHERE region = ? OR is_global = 1 ORDER BY family, region, key"
      )
      .bind(regionParam)
      .all();
    rows = res?.results || [];
  } else {
    const res = await db
      .prepare("SELECT * FROM sources_state ORDER BY family, region, key")
      .all();
    rows = res?.results || [];
  }

  return rows.map((r) => ({
    key: r.key,
    family: r.family,
    label: r.label,
    region: r.region,
    global: Boolean(r.is_global),
    app: r.app,
    platform: r.platform,
    url: r.url,
    poll_interval_min: r.poll_interval_min,
    state: r.state,
    version: r.version,
    updated_date: r.updated_date,
    summary: r.summary,
    note: r.note,
    last_checked: r.last_checked,
    last_success: r.last_success,
    last_error: r.last_error,
    last_error_at: r.last_error_at,
    last_change_at: r.last_change_at,
    last_change: r.last_change,
    latency_ms: r.latency_ms
  }));
}

/**
 * Build the response for `GET /api/history` with full filter validation.
 */
export async function getEventsHistory(db, query = {}) {
  const conditions = [];
  const params = [];

  if (query.region && query.region !== "all" && VALID_REGIONS.includes(query.region)) {
    conditions.push("region = ?");
    params.push(query.region);
  }

  if (query.status) {
    const statuses = String(query.status)
      .split(",")
      .map((s) => s.trim())
      .filter((s) => ["possible", "strong", "confirmed"].includes(s));
    if (statuses.length > 0) {
      conditions.push(`status IN (${statuses.map(() => "?").join(",")})`);
      params.push(...statuses);
    }
  }

  if (query.source) {
    const allowedFamilies = ["garena-news", "youtube", "google-play", "app-store"];
    if (allowedFamilies.includes(query.source)) {
      conditions.push("source_family = ?");
      params.push(query.source);
    }
  }

  if (query.type === "small") {
    conditions.push("patch_type IN ('small', 'listing')");
  } else if (query.type) {
    const types = String(query.type)
      .split(",")
      .map((t) => t.trim())
      .filter((t) =>
        ["small", "major", "maintenance", "announcement", "listing"].includes(t)
      );
    if (types.length > 0) {
      conditions.push(`patch_type IN (${types.map(() => "?").join(",")})`);
      params.push(...types);
    }
  }

  if (query.version) {
    const v = `%${String(query.version).trim().slice(0, 30)}%`;
    conditions.push("(COALESCE(old_version, '') LIKE ? OR COALESCE(new_version, '') LIKE ?)");
    params.push(v, v);
  }

  if (query.size === "known") {
    conditions.push("size IS NOT NULL AND size != ''");
  } else if (query.size === "unknown") {
    conditions.push("(size IS NULL OR size = '')");
  } else if (
    query.size &&
    ["2-3mb", "5mb", "10mb", "20mb", "other"].includes(query.size)
  ) {
    conditions.push("size_bucket = ?");
    params.push(query.size);
  }

  if (query.from && /^\d{4}-\d{2}-\d{2}$/.test(query.from)) {
    conditions.push("timestamp >= ?");
    params.push(`${query.from}T00:00:00.000Z`);
  }

  if (query.to && /^\d{4}-\d{2}-\d{2}$/.test(query.to)) {
    conditions.push("timestamp <= ?");
    params.push(`${query.to}T23:59:59.999Z`);
  }

  if (query.q) {
    const q = `%${String(query.q).trim().slice(0, 80)}%`;
    conditions.push(
      "(evidence LIKE ? OR source LIKE ? OR app LIKE ? OR classification_reason LIKE ?)"
    );
    params.push(q, q, q, q);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : "";
  const limit = Math.min(100, Math.max(1, parseInt(query.limit, 10) || 30));
  const offset = Math.max(0, parseInt(query.offset, 10) || 0);

  const countRow = await db
    .prepare(`SELECT COUNT(*) AS cnt FROM events ${whereClause}`)
    .bind(...params)
    .first();
  const total = Number(countRow?.cnt ?? 0);

  const rowsRes = await db
    .prepare(
      `SELECT * FROM events ${whereClause} ORDER BY timestamp DESC, id DESC LIMIT ? OFFSET ?`
    )
    .bind(...params, limit, offset)
    .all();

  const events = (rowsRes?.results || []).map(normalizeEventRow);
  return { events, total, limit, offset };
}

/**
 * Build the response for `POST /api/notifications`
 */
export async function getNotificationsSince(db, body = {}) {
  const region = VALID_REGIONS.includes(body.region) ? body.region : "India";
  const sinceId = Math.max(0, parseInt(body.sinceId, 10) || 0);
  const levels = Array.isArray(body.levels)
    ? body.levels.filter((l) => ["possible", "strong", "confirmed"].includes(l))
    : ["strong", "confirmed"];

  const latestRow = await db
    .prepare("SELECT MAX(id) AS max_id FROM events")
    .first();
  const latestId = Number(latestRow?.max_id ?? 0);

  if (sinceId === 0 || levels.length === 0) {
    return { events: [], latestId };
  }

  const placeholders = levels.map(() => "?").join(",");
  const res = await db
    .prepare(
      `SELECT * FROM events
       WHERE id > ? AND (region = ? OR is_global = 1) AND status IN (${placeholders})
       ORDER BY id DESC LIMIT 5`
    )
    .bind(sinceId, region, ...levels)
    .all();

  return {
    events: (res?.results || []).map(normalizeEventRow),
    latestId
  };
}

function normalizeEventRow(row) {
  let detail = row.evidence_detail;
  if (typeof detail === "string") {
    try {
      detail = JSON.parse(detail);
    } catch {
      detail = { raw: detail };
    }
  }
  return {
    ...row,
    is_global: Boolean(row.is_global),
    evidence_detail: detail
  };
}
