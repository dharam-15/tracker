// FF Small Patch Tracker — Patch Size Extractor, Version Comparator & Signal Classifier

export const SIGNAL_CATEGORIES = {
  confirmed: "CONFIRMED",
  strong: "STRONG UPDATE SIGNAL",
  possible: "POSSIBLE",
  none: "NO SIGNAL"
};

export const SOURCE_FAMILY_NAMES = {
  "garena-news": "Garena official news",
  "youtube": "official YouTube channel",
  "google-play": "Google Play listing",
  "app-store": "App Store listing"
};

/**
 * Classify a numeric MB value into one of the tracked small-patch buckets:
 * - 2-3mb: 1.5 – 3.8 MB (hotfix / config / event toggle)
 * - 5mb:   3.81 – 7.5 MB (mini resource / balance tweak)
 * - 10mb:  7.51 – 14.5 MB (small gameplay / weapon patch)
 * - 20mb:  14.51 – 35.0 MB (event pack / voice / mode assets)
 * - other: > 35 MB or < 1.5 MB
 */
export function bucketizeSizeMb(mb) {
  if (typeof mb !== "number" || Number.isNaN(mb) || mb <= 0) return null;
  if (mb >= 1.5 && mb <= 3.8) return "2-3mb";
  if (mb > 3.8 && mb <= 7.5) return "5mb";
  if (mb > 7.5 && mb <= 14.5) return "10mb";
  if (mb > 14.5 && mb <= 35.0) return "20mb";
  return "other";
}

/**
 * Extract patch size evidence from text (release notes, patch notes, announcements)
 * or from store metadata binary size delta.
 *
 * Rules:
 * - Never invent a size. Where reliable data is unavailable, return size = null (displayed as "Size unknown")
 *   and size_basis = "unavailable".
 * - Do not assume a change in full app binary size proves an in-game small patch.
 */
export function extractPatchSizeInfo(text = "", binarySizeDeltaBytes = null, sourceLabel = "source") {
  const clean = String(text || "");

  // Look for explicit range like "2-3 MB" or "2–3 MB"
  const rangeMatch = clean.match(/\b(\d+(?:\.\d+)?)\s*(?:-|–|to)\s*(\d+(?:\.\d+)?)\s*MB\b/i);
  if (rangeMatch) {
    const low = parseFloat(rangeMatch[1]);
    const high = parseFloat(rangeMatch[2]);
    const avg = Number(((low + high) / 2).toFixed(1));
    const isEst = /approx|est|around|~|about/i.test(clean);
    const basis = isEst ? "estimated" : "reported";
    return {
      size: `${low}–${high} MB (${basis === "estimated" ? "estimated" : "reported"} by ${sourceLabel})`,
      size_mb: avg,
      size_bucket: bucketizeSizeMb(avg),
      size_basis: basis
    };
  }

  // Look for explicit single MB figure like "3.2 MB", "5 MB", "10 MB", "20 MB"
  const mbMatch = clean.match(/(?:~|approx\.?\s*|about\s*)?\b(\d+(?:\.\d+)?)\s*MB\b/i);
  if (mbMatch) {
    const val = parseFloat(mbMatch[1]);
    if (val > 0 && val < 4000) {
      const isEst = /approx|est|around|~|about/i.test(mbMatch[0]) || /estimated/i.test(clean);
      const basis = isEst ? "estimated" : "reported";
      return {
        size: `${val} MB (${basis === "estimated" ? "estimated" : "reported"} by ${sourceLabel})`,
        size_mb: val,
        size_bucket: bucketizeSizeMb(val),
        size_basis: basis
      };
    }
  }

  // If binary size delta from App Store metadata is present, report it honestly as a store binary delta
  // without assuming it is an in-game small patch size.
  if (typeof binarySizeDeltaBytes === "number" && Math.abs(binarySizeDeltaBytes) >= 512 * 1024) {
    const deltaMb = Number((Math.abs(binarySizeDeltaBytes) / (1024 * 1024)).toFixed(1));
    const sign = binarySizeDeltaBytes > 0 ? "+" : "-";
    return {
      size: `${sign}${deltaMb} MB store binary delta (directly observed; does not prove in-game patch size)`,
      size_mb: deltaMb,
      size_bucket: bucketizeSizeMb(deltaMb),
      size_basis: "observed"
    };
  }

  return {
    size: null,
    size_mb: null,
    size_bucket: null,
    size_basis: "unavailable"
  };
}

/**
 * Compare two dotted version strings (e.g. "2.132.1" vs "2.132.2").
 * Returns:
 * - { changed: false } if equal or invalid
 * - { changed: true, direction: 1 | -1, patch_type: "small" | "major", reason: string }
 */
export function analyzeVersionChange(oldVersion, newVersion) {
  if (!oldVersion || !newVersion || oldVersion === newVersion) {
    return { changed: false };
  }
  const parse = (v) =>
    String(v)
      .trim()
      .replace(/^v/i, "")
      .split(".")
      .map((n) => parseInt(n, 10) || 0);

  const a = parse(oldVersion);
  const b = parse(newVersion);
  const len = Math.max(a.length, b.length);
  let direction = 0;
  let diffIndex = -1;

  for (let i = 0; i < len; i++) {
    const av = a[i] ?? 0;
    const bv = b[i] ?? 0;
    if (av !== bv) {
      direction = bv > av ? 1 : -1;
      diffIndex = i;
      break;
    }
  }

  if (direction <= 0) {
    return { changed: false };
  }

  // In Free Fire versioning (e.g. 2.132.1 -> 2.132.2 or 1.132.1 -> 1.132.2):
  // - Index 0 or 1 changing (e.g., 2.131.x -> 2.132.0) is a Major OB release.
  // - Index >= 2 changing (e.g., 2.132.1 -> 2.132.2) is a Small Patch / minor hotfix build.
  const isSmall = diffIndex >= 2;
  return {
    changed: true,
    direction,
    patch_type: isSmall ? "small" : "major",
    reason: isSmall
      ? `Only the patch/build component changed (${oldVersion} → ${newVersion}), indicating a small client patch rather than a full OB version jump.`
      : `Major/minor version component incremented (${oldVersion} → ${newVersion}), matching a major OB release.`
  };
}

/**
 * Compute a deterministic deduplication key so repeated polling of the same change
 * never creates duplicate events.
 */
export function computeDedupKey({ source_key, kind, old_version, new_version, signature }) {
  const raw = [
    source_key || "",
    kind || "",
    old_version || "",
    new_version || "",
    signature || ""
  ].join("|");
  // FNV-1a 64-bit style hex digest (fast, synchronous, works identically in Node and Workers)
  let h1 = 0xdeadbeef ^ raw.length;
  let h2 = 0x41c6ce57 ^ raw.length;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return `ev_${(h2 >>> 0).toString(16).padStart(8, "0")}${(h1 >>> 0).toString(16).padStart(8, "0")}`;
}

/**
 * Evaluate the regional signal status from recent events within the observation window.
 * Implements the 4 exact required signal categories:
 * - CONFIRMED
 * - STRONG UPDATE SIGNAL
 * - POSSIBLE
 * - NO SIGNAL
 */
export function classifyRegionalSignal(region, events, now = new Date(), windowHours = 72) {
  const cutoffMs = now.getTime() - windowHours * 3600 * 1000;
  const windowEvents = events
    .filter(
      (ev) =>
        new Date(ev.timestamp).getTime() >= cutoffMs &&
        (ev.region === region || Boolean(ev.is_global))
    )
    .sort((a, b) => a.timestamp.localeCompare(b.timestamp));

  const regionalEvents = windowEvents.filter((ev) => ev.region === region);
  const families = new Set(windowEvents.map((ev) => ev.source_family));
  const familyLabels = [
    ...new Set(
      windowEvents.map((ev) => SOURCE_FAMILY_NAMES[ev.source_family] ?? ev.source_family)
    )
  ];

  let level = "none";
  if (windowEvents.length > 0) {
    if (
      regionalEvents.some((ev) => ev.kind === "version_change" && ev.status === "confirmed")
    ) {
      level = "confirmed";
    } else if (
      regionalEvents.length > 0 &&
      (families.size >= 2 || regionalEvents.some((ev) => ev.status === "strong"))
    ) {
      level = "strong";
    } else {
      level = "possible";
    }
  }

  const latestConfirmed = [...regionalEvents]
    .reverse()
    .find((ev) => ev.kind === "version_change" && ev.status === "confirmed");
  const globalOnly = regionalEvents.length === 0 && windowEvents.length > 0;

  let headline;
  const reasons = [];

  switch (level) {
    case "confirmed":
      headline = `${
        latestConfirmed.patch_type === "small" ? "Small patch" : "Update"
      } confirmed: ${latestConfirmed.app} ${latestConfirmed.old_version} → ${
        latestConfirmed.new_version
      } (${region}).`;
      reasons.push(
        `CONFIRMED: A public store listing for ${region} directly verified a higher version number (${latestConfirmed.old_version} → ${latestConfirmed.new_version}).`
      );
      break;
    case "strong":
      headline = `Strong update signal for ${region}: ${
        familyLabels.length >= 2
          ? `${familyLabels.length} independent public sources changed`
          : "store release metadata changed without a version bump"
      }.`;
      reasons.push(`Independent source families with changes: ${familyLabels.join(", ")}.`);
      reasons.push(
        "STRONG UPDATE SIGNAL: Multiple independent observations or store listing metadata updates support a possible small patch, but no store version bump is confirmed yet."
      );
      break;
    case "possible":
      headline = globalOnly
        ? `Possible signal from a global official source — not confirmed for ${region}.`
        : "Possible minor-update signal detected.";
      reasons.push(
        `POSSIBLE: Limited or indirect evidence from ${familyLabels.join(
          ", "
        )}. Single-source or global hints are kept separate from confirmed updates.`
      );
      break;
    default:
      headline = "No reliable public signal detected.";
      reasons.push(
        `NO SIGNAL: No qualifying update evidence was detected in monitored public sources for ${region} during the last ${windowHours} hours. ("No signal" does not mean an in-game update is impossible.)`
      );
  }

  for (const ev of [...windowEvents].reverse().slice(0, 6)) {
    reasons.push(
      `${ev.timestamp.slice(0, 16).replace("T", " ")} UTC · ${ev.source}: ${ev.evidence}`
    );
  }

  const findFirst = (pred) => windowEvents.find(pred) ?? null;
  const announcement = findFirst(
    (e) => e.kind === "official_post" || e.kind === "official_video"
  );
  const metadata = findFirst((e) => e.kind === "listing_change");
  const version = findFirst((e) => e.kind === "version_change");
  const step = (key, label, ev, reached = Boolean(ev)) => ({
    key,
    label,
    reached,
    at: reached && ev ? ev.timestamp : null,
    detail: reached && ev ? `${ev.source}${ev.new_version ? ` · ${ev.new_version}` : ""}` : null
  });

  return {
    region,
    level,
    label: SIGNAL_CATEGORIES[level],
    headline,
    reasons,
    evidence: [...windowEvents].reverse(),
    timeline: [
      step("announcement", "Public announcement", announcement),
      step("metadata", "Metadata change", metadata),
      step("version", "Version change", version),
      step("confirmed", "Update confirmed", version, level === "confirmed")
    ],
    windowHours,
    detectedAt: windowEvents[windowEvents.length - 1]?.timestamp ?? null
  };
}
