// FF Small Patch Tracker — Public Source Registry & Live Pollers
// Uses only legitimate, publicly accessible endpoints:
// 1. Apple iTunes Lookup API (JSON metadata for Free Fire & Free Fire MAX per country)
// 2. Google Play public store pages (version, updated date, availability per country)
// 3. Official Garena Free Fire News & Patch Notes pages (ff.garena.com)
// 4. Official Free Fire YouTube Channel Atom/RSS feeds (youtube.com/feeds/videos.xml)

const REGION_COUNTRIES = [
  { region: "India", cc: "in", gl: "IN" },
  { region: "Bangladesh", cc: "bd", gl: "BD" },
  { region: "Indonesia", cc: "id", gl: "ID" },
  { region: "Singapore", cc: "sg", gl: "SG" },
  { region: "Other", cc: "us", gl: "US" }
];

export const MONITORED_SOURCES = [
  // Official Garena News sources (poll interval: 20 min)
  {
    key: "garena-news:global:patch-notes",
    family: "garena-news",
    label: "Garena Official Patch Notes · Global (EN)",
    region: "Other",
    is_global: 1,
    app: "Free Fire MAX",
    platform: "Web",
    url: "https://ff.garena.com/en/news/20/",
    poll_interval_min: 20,
    note: "Verifies official OB patch notes and small hotfix notices published on ff.garena.com."
  },
  {
    key: "garena-news:Indonesia:news",
    family: "garena-news",
    label: "Garena Official News · Indonesia (ID)",
    region: "Indonesia",
    is_global: 0,
    app: "Free Fire MAX",
    platform: "Web",
    url: "https://ff.garena.com/id/news/",
    poll_interval_min: 20,
    note: "Verifies regional Indonesian patch announcements, maintenance notices, and event updates."
  },
  // Official YouTube Atom/RSS feeds (poll interval: 30 min)
  {
    key: "youtube:India:official",
    family: "youtube",
    label: "YouTube · Free Fire India Official",
    region: "India",
    is_global: 0,
    app: "Free Fire MAX",
    platform: "YouTube",
    url: "https://www.youtube.com/feeds/videos.xml?channel_id=UC4AB0_ectRryjCF_ugD0U8w",
    poll_interval_min: 30,
    note: "Verifies official Free Fire India video announcements and patch previews via public Atom feed."
  },
  {
    key: "youtube:Indonesia:official",
    family: "youtube",
    label: "YouTube · Garena Free Fire Indonesia",
    region: "Indonesia",
    is_global: 0,
    app: "Free Fire MAX",
    platform: "YouTube",
    url: "https://www.youtube.com/feeds/videos.xml?channel_id=UCM3SMB1jINy_NxH1O01z5gA",
    poll_interval_min: 30,
    note: "Verifies official Garena Free Fire Indonesia video announcements via public Atom feed."
  },
  {
    key: "youtube:global:official",
    family: "youtube",
    label: "YouTube · Garena Free Fire Global/TH",
    region: "Other",
    is_global: 1,
    app: "Free Fire MAX",
    platform: "YouTube",
    url: "https://www.youtube.com/feeds/videos.xml?channel_id=UCe5H8YhDjg_441KjjS5qrAg",
    poll_interval_min: 30,
    note: "Verifies global Free Fire patch teasers and maintenance announcements."
  },
  // Regional Google Play & Apple App Store listings
  ...REGION_COUNTRIES.flatMap(({ region, cc, gl }) => [
    {
      key: `google-play:${region}:ff`,
      family: "google-play",
      label: `Google Play · Free Fire · ${gl}`,
      region,
      is_global: 0,
      app: "Free Fire",
      platform: "Android",
      url: `https://play.google.com/store/apps/details?id=com.dts.freefireth&hl=en&gl=${gl}`,
      poll_interval_min: 20,
      note: `Verifies Android version, listing date, and regional availability for Free Fire (com.dts.freefireth) in ${region}.`
    },
    {
      key: `google-play:${region}:ffmax`,
      family: "google-play",
      label: `Google Play · Free Fire MAX · ${gl}`,
      region,
      is_global: 0,
      app: "Free Fire MAX",
      platform: "Android",
      url: `https://play.google.com/store/apps/details?id=com.dts.freefiremax&hl=en&gl=${gl}`,
      poll_interval_min: 20,
      note: `Verifies Android version, listing date, and release notes for Free Fire MAX (com.dts.freefiremax) in ${region}.`
    },
    {
      key: `app-store:${region}:ff`,
      family: "app-store",
      label: `App Store · Free Fire · ${gl}`,
      region,
      is_global: 0,
      app: "Free Fire",
      platform: "iOS",
      url: `https://itunes.apple.com/lookup?id=1300146617&country=${cc}`,
      poll_interval_min: 15,
      note: `Verifies iOS version, currentVersionReleaseDate, releaseNotes, and fileSizeBytes for Free Fire (id1300146617) in ${region}.`
    },
    {
      key: `app-store:${region}:ffmax`,
      family: "app-store",
      label: `App Store · Free Fire MAX · ${gl}`,
      region,
      is_global: 0,
      app: "Free Fire MAX",
      platform: "iOS",
      url: `https://itunes.apple.com/lookup?id=1480516829&country=${cc}`,
      poll_interval_min: 15,
      note: `Verifies iOS version, currentVersionReleaseDate, releaseNotes, and fileSizeBytes for Free Fire MAX (id1480516829) in ${region}.`
    }
  ])
];

export function simpleHash(text) {
  const str = String(text || "").trim();
  if (!str) return null;
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

async function fetchWithRetry(url, options = {}, retries = 1, timeoutMs = 8000) {
  let lastErr;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          "User-Agent":
            "FFSmallPatchTracker/1.0 (+https://github.com/ff-small-patch-tracker; public-metadata-monitor)",
          Accept: "application/json, text/html, application/xml, text/xml;q=0.9, */*;q=0.8",
          ...(options.headers || {})
        }
      });
      clearTimeout(timer);
      if (res.status >= 500 && attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
        continue;
      }
      return res;
    } catch (err) {
      clearTimeout(timer);
      lastErr = err;
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
      }
    }
  }
  throw lastErr || new Error("Network request failed");
}

export function parseItunesPayload(json, source) {
  if (!json || typeof json.resultCount !== "number") {
    throw new Error("Invalid iTunes Lookup JSON response");
  }
  if (json.resultCount === 0 || !Array.isArray(json.results) || !json.results[0]) {
    return {
      state: "not_listed",
      version: null,
      updated_date: null,
      file_size_bytes: null,
      release_notes: null,
      release_notes_hash: null,
      summary: "Not listed in this regional storefront"
    };
  }
  const item = json.results[0];
  const version = item.version ? String(item.version).trim() : null;
  const updated_date = item.currentVersionReleaseDate
    ? String(item.currentVersionReleaseDate).slice(0, 10)
    : null;
  const file_size_bytes = item.fileSizeBytes ? Number(item.fileSizeBytes) : null;
  const release_notes = item.releaseNotes ? String(item.releaseNotes).trim() : "";
  return {
    state: "working",
    version,
    updated_date,
    file_size_bytes,
    release_notes,
    release_notes_hash: simpleHash(release_notes),
    summary: `v${version ?? "?"} · released ${updated_date ?? "unknown"}${
      file_size_bytes ? ` · ${(file_size_bytes / 1048576).toFixed(0)} MB binary` : ""
    }`
  };
}

export function parseGooglePlayHtml(html, status, source) {
  if (
    status === 404 ||
    /We're sorry, the requested URL was not found/i.test(html) ||
    /id="error-section"/i.test(html)
  ) {
    return {
      state: "not_listed",
      version: null,
      updated_date: null,
      file_size_bytes: null,
      release_notes: null,
      release_notes_hash: null,
      summary: "Not listed in this regional Google Play storefront"
    };
  }

  // Extract version like "2.132.1" or "1.132.1" from AF_initDataCallback or JSON metadata
  const versionMatch =
    html.match(/\[\[\["([12]\.\d{2,3}\.\d+)"\]\]/) ||
    html.match(/"softwareVersion"\s*:\s*"([^"]+)"/) ||
    html.match(/\b([12]\.\d{2,3}\.\d{1,3})\b/);
  const version = versionMatch ? versionMatch[1].trim() : null;

  // Extract updated date like "Updated on Oct 1, 2026" or "Sep 10, 2026"
  const updatedMatch =
    html.match(/Updated on<\/div><div[^>]*>([^<]+)<\/div>/i) ||
    html.match(/"datePublished"\s*:\s*"([^"]+)"/i) ||
    html.match(/\b((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2},\s+20\d{2})\b/);
  const updated_date = updatedMatch ? updatedMatch[1].trim() : null;

  // Extract What's New text if present
  const notesMatch =
    html.match(/What&#39;s new<\/h2>.*?<div[^>]* itemprop="description"[^>]*>(.*?)<\/div>/is) ||
    html.match(/What's new.*?>([^<]{15,500})</is);
  const release_notes = notesMatch
    ? notesMatch[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim()
    : "";

  return {
    state: "working",
    version,
    updated_date,
    file_size_bytes: null,
    release_notes,
    release_notes_hash: simpleHash(release_notes),
    summary: version
      ? `v${version}${updated_date ? ` · updated ${updated_date}` : ""}`
      : `Listed${updated_date ? ` · updated ${updated_date}` : ""}`
  };
}

export function parseGarenaNewsHtml(html) {
  // Look for article links or titles such as /article/1711/ or OB55 PATCH NOTES
  const articleMatch =
    html.match(/href="[^"]*\/article\/(\d+)\/?"[^>]*>(.*?)<\/a>/is) ||
    html.match(/(OB\d+\s+PATCH\s+NOTES|Patch\s+Notes\s*:[^<\n]+)/i);

  const dateMatch = html.match(/\b(\d{2}\/\d{2}\/20\d{2})\b/);
  const sizeMatch = html.match(/\b(\d+(?:\.\d+)?(?:\s*-\s*\d+(?:\.\d+)?)?\s*MB)\b/i);

  let latestId = null;
  let title = null;

  if (articleMatch) {
    if (articleMatch[2]) {
      latestId = `article-${articleMatch[1]}`;
      title = articleMatch[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    } else {
      title = articleMatch[1].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
      latestId = `title-${simpleHash(title)}`;
    }
  } else {
    const fallbackTitle = html.match(/<title>([^<]+)<\/title>/i);
    title = fallbackTitle ? fallbackTitle[1].trim() : "Garena News Index";
    latestId = `hash-${simpleHash(title)}`;
  }

  return {
    state: "working",
    latest_item_id: latestId,
    title,
    updated_date: dateMatch ? dateMatch[1] : null,
    release_notes: sizeMatch ? `${title} (${sizeMatch[1]})` : title,
    content_hash: simpleHash(`${latestId}|${title}|${dateMatch ? dateMatch[1] : ""}`),
    summary: `${title}${dateMatch ? ` (${dateMatch[1]})` : ""}`
  };
}

export function parseYoutubeFeedXml(xml) {
  const entryMatch = xml.match(/<entry>([\s\S]*?)<\/entry>/i);
  if (!entryMatch) {
    return {
      state: "working",
      latest_item_id: null,
      title: null,
      updated_date: null,
      release_notes: "",
      content_hash: simpleHash(xml.slice(0, 500)),
      summary: "Feed reachable (no recent video entries)"
    };
  }
  const entry = entryMatch[1];
  const vidMatch = entry.match(/<yt:videoId>([^<]+)<\/yt:videoId>/i);
  const titleMatch = entry.match(/<title>([^<]+)<\/title>/i);
  const pubMatch = entry.match(/<published>([^<]+)<\/published>/i);
  const descMatch = entry.match(/<media:description>([\s\S]*?)<\/media:description>/i);

  const videoId = vidMatch ? vidMatch[1].trim() : null;
  const title = titleMatch ? titleMatch[1].trim() : "Official video";
  const published = pubMatch ? pubMatch[1].trim().slice(0, 10) : null;
  const desc = descMatch ? descMatch[1].trim().slice(0, 400) : "";

  return {
    state: "working",
    latest_item_id: videoId,
    title,
    updated_date: published,
    release_notes: `${title}. ${desc}`.trim(),
    content_hash: simpleHash(`${videoId}|${title}`),
    summary: `"${title}" (${published ?? "recent"})`
  };
}

/**
 * Poll a single public source definition and return normalized observation metadata.
 * Supports custom `fetcher` injection for deterministic unit/integration testing.
 */
export async function pollSingleSource(source, customFetcher = null) {
  const startMs = Date.now();
  try {
    if (customFetcher) {
      const mockResult = await customFetcher(source);
      const latency_ms = Date.now() - startMs;
      return {
        ...mockResult,
        latency_ms: mockResult.latency_ms ?? latency_ms,
        state:
          mockResult.state === "working" && (mockResult.latency_ms ?? latency_ms) > 4000
            ? "slow"
            : mockResult.state || "working"
      };
    }

    const res = await fetchWithRetry(source.url, {}, 1, 8000);
    const latency_ms = Date.now() - startMs;

    if (source.family === "app-store") {
      if (!res.ok) throw new Error(`HTTP ${res.status} from iTunes Lookup API`);
      const json = await res.json();
      const parsed = parseItunesPayload(json, source);
      if (parsed.state === "working" && latency_ms > 4000) parsed.state = "slow";
      return { ...parsed, latency_ms };
    }

    if (source.family === "google-play") {
      const text = await res.text();
      if (!res.ok && res.status !== 404) {
        throw new Error(`HTTP ${res.status} from Google Play`);
      }
      const parsed = parseGooglePlayHtml(text, res.status, source);
      if (parsed.state === "working" && latency_ms > 4000) parsed.state = "slow";
      return { ...parsed, latency_ms };
    }

    if (source.family === "garena-news") {
      if (!res.ok) throw new Error(`HTTP ${res.status} from Garena News`);
      const html = await res.text();
      const parsed = parseGarenaNewsHtml(html);
      if (parsed.state === "working" && latency_ms > 4000) parsed.state = "slow";
      return { ...parsed, latency_ms };
    }

    if (source.family === "youtube") {
      if (!res.ok) throw new Error(`HTTP ${res.status} from YouTube Atom feed`);
      const xml = await res.text();
      const parsed = parseYoutubeFeedXml(xml);
      if (parsed.state === "working" && latency_ms > 4000) parsed.state = "slow";
      return { ...parsed, latency_ms };
    }

    throw new Error(`Unsupported source family: ${source.family}`);
  } catch (err) {
    const latency_ms = Date.now() - startMs;
    return {
      state: "unavailable",
      error: err.name === "AbortError" ? "Request timed out (8s)" : err.message,
      latency_ms
    };
  }
}
