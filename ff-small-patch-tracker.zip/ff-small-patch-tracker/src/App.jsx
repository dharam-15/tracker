import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  REGIONS,
  SIZE_UNKNOWN_LABEL,
  NO_SIGNAL_HEADLINE,
  SIGNAL_LABELS,
  SIGNAL_DOTS,
  SIGNAL_STRENGTH,
  PATCH_TYPES,
  SMALL_PATCH_BUCKETS,
  SIZE_BASIS_LABELS,
  SOURCE_GROUP_TITLES,
  SOURCE_STATE_META
} from "./constants.js";
import { api } from "./api.js";
import {
  isNotificationSupported,
  isNotificationEnabled,
  getNotificationLevels,
  setNotificationLevels,
  requestNotificationPermission,
  disableNotifications,
  pollNotificationsForRegion,
  sendTestNotification
} from "./notifications.js";
import {
  buildDemoStatus,
  buildDemoSources,
  queryDemoHistory,
  runDemoCheck
} from "./demo.js";

function formatRelativePast(iso, nowMs = Date.now()) {
  if (!iso) return "never";
  const sec = Math.round((nowMs - new Date(iso).getTime()) / 1000);
  if (sec < 0) return "just now";
  if (sec < 60) return `${sec}s ago`;
  const min = Math.round(sec / 60);
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  return hr < 48 ? `${hr} h ago` : `${Math.round(hr / 24)} days ago`;
}

function formatRelativeFuture(iso, nowMs = Date.now()) {
  if (!iso) return "—";
  const min = Math.round((new Date(iso).getTime() - nowMs) / 60000);
  return min <= 0 ? "any moment" : `approximately ${min} min`;
}

function formatDateTime(iso) {
  return iso
    ? new Date(iso).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })
    : "—";
}

function safeStorageGet(key, fallback) {
  try {
    return localStorage.getItem(key) ?? fallback;
  } catch {
    return fallback;
  }
}

function safeStorageSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    // ignore storage errors
  }
}

const SkeletonCard = ({ title }) => (
  <article className="card skeleton" aria-busy="true">
    <h3>{title}</h3>
    <div className="sk-line" />
    <div className="sk-line w60" />
  </article>
);

function UpdateRadar({ status, loading, error, now, onWhy, mode, onSelectSizeBucket }) {
  if (loading) {
    return (
      <section className="radar panel skeleton" aria-busy="true">
        <div className="sk-line w40" />
        <div className="sk-block" />
      </section>
    );
  }

  if (!status) {
    return (
      <section className="radar panel">
        <h2 className="panel-title">🔮 Update Radar</h2>
        <p className="muted">
          Live status is unavailable{error ? ` (${error})` : ""}. No sample data is substituted.
        </p>
      </section>
    );
  }

  const sig = status.signal;
  const topEvidence = sig.evidence[0] ?? null;
  const blips = sig.evidence.slice(0, 6);
  const gapMin = status.monitoring?.gapMinutes ?? null;

  return (
    <section className={`radar panel level-${sig.level}`} aria-labelledby="radar-title">
      <div className="radar-head">
        <h2 id="radar-title" className="panel-title">
          🔮 Update Radar
        </h2>
        <span className="radar-region">
          🌍 {status.region}
          {mode === "demo" ? " · DEMO" : ""}
        </span>
      </div>

      <div className="radar-body">
        <div className="scope" aria-hidden="true">
          <svg viewBox="0 0 200 200">
            <defs>
              <radialGradient id="glow" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="var(--lvl)" stopOpacity="0.25" />
                <stop offset="100%" stopColor="var(--lvl)" stopOpacity="0" />
              </radialGradient>
              <linearGradient id="sweep" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="var(--lvl)" stopOpacity="0" />
                <stop offset="100%" stopColor="var(--lvl)" stopOpacity="0.55" />
              </linearGradient>
            </defs>
            <circle cx="100" cy="100" r="96" fill="url(#glow)" />
            {[96, 72, 48, 24].map((r) => (
              <circle key={r} cx="100" cy="100" r={r} className="ring" />
            ))}
            <line x1="4" y1="100" x2="196" y2="100" className="ring" />
            <line x1="100" y1="4" x2="100" y2="196" className="ring" />
            <g className="sweep">
              <path
                d="M100 100 L196 100 A96 96 0 0 0 167.9 32.1 Z"
                fill="url(#sweep)"
              />
            </g>
            {blips.map((ev, idx) => {
              const angle = (idx * 137 + 40) * (Math.PI / 180);
              const radius =
                ev.status === "confirmed" ? 22 : ev.status === "strong" ? 48 : 74;
              return (
                <circle
                  key={ev.id}
                  cx={100 + Math.cos(angle) * radius}
                  cy={100 + Math.sin(angle) * radius}
                  r={ev.status === "confirmed" ? 6 : 4}
                  className={`blip st-${ev.status}`}
                  style={{ animationDelay: `${idx * 0.4}s` }}
                />
              );
            })}
          </svg>
          <div className="scope-label">{SIGNAL_DOTS[sig.level]}</div>
        </div>

        <div className="radar-readout">
          <div className="level-tag">
            {SIGNAL_DOTS[sig.level]} {SIGNAL_LABELS[sig.level] ?? sig.label}
          </div>
          <p className="headline">
            {sig.level === "none" ? NO_SIGNAL_HEADLINE : sig.headline}
          </p>

          <div
            className="meter"
            aria-label={`Signal strength ${SIGNAL_STRENGTH[sig.level]} of 3`}
          >
            {[1, 2, 3].map((step) => (
              <span
                key={step}
                className={step <= SIGNAL_STRENGTH[sig.level] ? "on" : ""}
              />
            ))}
            <em>Signal strength {SIGNAL_STRENGTH[sig.level]}/3</em>
          </div>

          {sig.level === "none" && (
            <div className="gap-notice">
              <strong>Note:</strong> &ldquo;NO SIGNAL&rdquo; means no qualifying change was
              detected during checks performed — it does not mean a small in-game patch is
              impossible.{" "}
              {status.lastCheck
                ? `Last successful check: ${formatRelativePast(status.lastCheck, now)}${
                    gapMin && gapMin > status.intervalMinutes * 2
                      ? ` (monitoring gap of ${gapMin} min detected)`
                      : "."
                  }`
                : "No check has completed yet."}
            </div>
          )}

          <div className="size-pillars" aria-label="Tracked small patch size targets">
            {SMALL_PATCH_BUCKETS.slice(0, 4).map((b) => {
              const hasMatch = sig.evidence.some((e) => e.size_bucket === b.id);
              return (
                <button
                  key={b.id}
                  type="button"
                  className={`size-pillar ${hasMatch ? "active" : ""}`}
                  onClick={() => onSelectSizeBucket && onSelectSizeBucket(b.id)}
                  title={`${b.label}: ${b.desc} (click to filter history)`}
                >
                  📦 {b.label} {hasMatch ? "●" : ""}
                </button>
              );
            })}
          </div>

          <dl className="facts">
            <div>
              <dt>What changed</dt>
              <dd>
                {topEvidence
                  ? topEvidence.evidence
                  : `Nothing in the last ${sig.windowHours} h`}
              </dd>
            </div>
            <div>
              <dt>Detection time</dt>
              <dd>{topEvidence ? formatDateTime(topEvidence.timestamp) : "—"}</dd>
            </div>
            <div>
              <dt>Source</dt>
              <dd>
                {topEvidence ? (
                  <a href={topEvidence.source_url} target="_blank" rel="noreferrer">
                    {topEvidence.source}
                  </a>
                ) : (
                  "—"
                )}
              </dd>
            </div>
            <div>
              <dt>Last check</dt>
              <dd>{status.lastCheck ? formatRelativePast(status.lastCheck, now) : "not yet"}</dd>
            </div>
            <div>
              <dt>Next check</dt>
              <dd>{formatRelativeFuture(status.nextCheck, now)}</dd>
            </div>
          </dl>

          {topEvidence && (
            <button className="btn-why" onClick={() => onWhy(topEvidence)}>
              WHY DID WE DETECT THIS?
            </button>
          )}
        </div>
      </div>

      <ol className="timeline" aria-label="How the signal developed">
        {sig.timeline.map((step, idx) => (
          <li
            key={step.key}
            className={step.reached ? "reached" : ""}
            style={{ animationDelay: `${idx * 80}ms` }}
          >
            <span className="node" />
            <div>
              <strong>{step.label}</strong>
              <small>
                {step.reached
                  ? `${formatDateTime(step.at)}${step.detail ? ` · ${step.detail}` : ""}`
                  : "not observed"}
              </small>
            </div>
          </li>
        ))}
      </ol>

      <details className="reasons">
        <summary>Signal reasoning ({sig.reasons.length})</summary>
        <ul>
          {sig.reasons.map((r, i) => (
            <li key={i}>{r}</li>
          ))}
        </ul>
        <p className="muted small">
          A signal describes the weight of public evidence. Predictions are kept strictly
          separate from confirmed updates, and app binary size changes alone do not prove an
          in-game small patch.
        </p>
      </details>
    </section>
  );
}

function CheckProgressPanel({ progress, checking, onClose }) {
  const last = progress[progress.length - 1];
  const lastSource = [...progress].reverse().find((p) => p.type === "source");
  const pct =
    last.type === "complete" || last.type === "error"
      ? 100
      : lastSource
      ? Math.round((lastSource.index / lastSource.total) * 85)
      : 5;
  const logItems = progress
    .filter((p) => p.type !== "source" || p.state !== "working")
    .slice(-7);

  return (
    <section className={`checkpanel ${last.type}`} aria-live="polite">
      <div className="cp-head">
        <strong>
          {checking ? "Checking…" : last.type === "error" ? "Check notice" : "Complete"}
        </strong>
        {!checking && (
          <button className="link" onClick={onClose}>
            Dismiss
          </button>
        )}
      </div>
      <div className="cp-bar">
        <span style={{ transform: `scaleX(${pct / 100})` }} />
      </div>
      <p className="cp-now">{last.message}</p>
      <ul className="cp-log">
        {logItems.map((item, idx) => (
          <li
            key={idx}
            className={`t-${item.type} ${item.type === "source" ? `s-${item.state}` : ""}`}
          >
            {item.message}
          </li>
        ))}
      </ul>
    </section>
  );
}

function CurrentVersionCard({ status, loading }) {
  if (loading) return <SkeletonCard title="🔄 Current Version" />;
  return (
    <article className="card">
      <h3>🔄 Current Version</h3>
      {status ? (
        <ul className="versions">
          {status.versions.map((v) => {
            const meta = SOURCE_STATE_META[v.state] ?? SOURCE_STATE_META.pending;
            return (
              <li key={`${v.app}-${v.platform}`}>
                <span className="v-app">
                  {v.app} <em>{v.platform}</em>
                </span>
                <span className="v-num">
                  {v.state === "not_listed"
                    ? "Not listed"
                    : v.state === "pending"
                    ? "Not checked yet"
                    : v.version ?? "Unknown"}
                </span>
                <a
                  className="v-meta"
                  href={v.source_url}
                  target="_blank"
                  rel="noreferrer"
                >
                  {meta.dot}{" "}
                  {v.updated
                    ? `listed ${v.updated.length > 12 ? v.updated.slice(0, 10) : v.updated}`
                    : meta.label}
                </a>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="muted">Unavailable.</p>
      )}
      <p className="card-foot">
        From public store listings for {status?.region ?? "this region"}. A different region
        may differ.
      </p>
    </article>
  );
}

function LatestPatchCard({ status, loading, onWhy }) {
  if (loading) return <SkeletonCard title="📦 Latest Patch" />;
  const patch = status?.latestConfirmed ?? status?.latestPatch ?? null;
  return (
    <article className="card">
      <h3>📦 Latest Patch</h3>
      {patch ? (
        <>
          <p className="lp-title">
            {SIGNAL_DOTS[patch.status]} {PATCH_TYPES[patch.patch_type] ?? patch.patch_type} ·{" "}
            {patch.app}
          </p>
          <dl className="mini">
            <div>
              <dt>🔄 Version</dt>
              <dd>
                {patch.old_version &&
                patch.new_version &&
                patch.old_version !== patch.new_version
                  ? `${patch.old_version} → ${patch.new_version}`
                  : patch.new_version ?? "—"}
              </dd>
            </div>
            <div>
              <dt>📦 Size</dt>
              <dd>{patch.size ?? SIZE_UNKNOWN_LABEL}</dd>
            </div>
            <div>
              <dt>🕐 Detected</dt>
              <dd>{formatDateTime(patch.timestamp)}</dd>
            </div>
            <div>
              <dt>🟢 Classification</dt>
              <dd>{SIGNAL_LABELS[patch.status] ?? patch.status}</dd>
            </div>
          </dl>
          <button className="btn-why sm" onClick={() => onWhy(patch)}>
            WHY DID WE DETECT THIS?
          </button>
        </>
      ) : (
        <p className="muted">
          No patch or signal has been recorded for {status?.region ?? "this region"} yet.
          History builds up from the first monitoring pass onward.
        </p>
      )}
    </article>
  );
}

function MonitoringStatusCard({ status, loading, now, error }) {
  if (loading) return <SkeletonCard title="📡 Monitoring Status" />;
  if (!status) {
    return (
      <article className="card warn">
        <h3>📡 Monitoring Status</h3>
        <p>⚠️ Monitoring temporarily unavailable.</p>
        <p className="muted small">{error}</p>
      </article>
    );
  }
  const mon = status.monitoring;
  const src = status.sources;
  return (
    <article className={`card mon-${mon.state}`}>
      <h3>📡 Monitoring Status</h3>
      <div className="mon-big">
        <span className={`dot ${mon.state}`} />
        {mon.state === "ok"
          ? "Active"
          : mon.state === "degraded"
          ? "Active · some sources failing"
          : mon.state === "never"
          ? "Waiting for first check"
          : "Temporarily unavailable"}
      </div>
      <dl className="mini">
        <div>
          <dt>🕐 Last checked</dt>
          <dd>{status.lastCheck ? formatRelativePast(status.lastCheck, now) : "never"}</dd>
        </div>
        <div>
          <dt>Next check</dt>
          <dd>{formatRelativeFuture(status.nextCheck, now)}</dd>
        </div>
        <div>
          <dt>Sources</dt>
          <dd>
            🟢 {src.working} · 🟡 {src.slow} · 🔴 {src.unavailable}
            {src.not_listed ? ` · ⚫ ${src.not_listed}` : ""}
          </dd>
        </div>
        <div>
          <dt>Interval</dt>
          <dd>every {status.intervalMinutes} min</dd>
        </div>
      </dl>
      <p className="card-foot">{mon.message}</p>
    </article>
  );
}

function NotificationsCard({ mode, region }) {
  const [enabled, setEnabled] = useState(isNotificationEnabled);
  const [levels, setLevels] = useState(getNotificationLevels);
  const [note, setNote] = useState(null);
  const supported = isNotificationSupported();
  const denied = supported && Notification.permission === "denied";

  useEffect(() => {
    setNotificationLevels(levels);
  }, [levels]);

  const toggleNotifications = async () => {
    if (enabled) {
      disableNotifications();
      setEnabled(false);
      setNote("Notifications off.");
      return;
    }
    const perm = await requestNotificationPermission();
    if (perm === "granted") {
      setEnabled(true);
      setNote(`On for ${region}. Only new events are notified, once each.`);
    } else {
      setNote(
        perm === "unsupported"
          ? "This browser does not support notifications."
          : "Permission was not granted. Allow notifications in your browser settings."
      );
    }
  };

  return (
    <article className="card">
      <h3>🔔 Notifications</h3>
      {supported ? (
        <>
          <label className="switch">
            <input
              type="checkbox"
              checked={enabled}
              onChange={toggleNotifications}
              disabled={denied}
            />
            <span className="track">
              <span className="thumb" />
            </span>
            <span>
              {enabled ? "Enabled" : denied ? "Blocked in browser settings" : "Disabled"}
            </span>
          </label>
          <fieldset className="levels" disabled={!enabled}>
            <legend>Notify me for</legend>
            {["possible", "strong", "confirmed"].map((lvl) => (
              <label key={lvl}>
                <input
                  type="checkbox"
                  checked={levels.includes(lvl)}
                  onChange={(e) =>
                    setLevels(
                      e.target.checked
                        ? [...levels, lvl]
                        : levels.filter((x) => x !== lvl)
                    )
                  }
                />
                {SIGNAL_DOTS[lvl]} {SIGNAL_LABELS[lvl]}
              </label>
            ))}
          </fieldset>
          {enabled && (
            <button
              className="link"
              onClick={() =>
                sendTestNotification().catch(() => setNote("Test notification failed."))
              }
            >
              Send a test notification
            </button>
          )}
        </>
      ) : (
        <p className="muted">
          This browser does not support notifications. On iPhone, add the tracker to your Home
          Screen first (iOS 16.4+).
        </p>
      )}
      {note && <p className="card-foot">{note}</p>}
      {mode === "demo" && (
        <p className="card-foot">Demo mode never sends notifications.</p>
      )}
    </article>
  );
}

const HISTORY_TABS = [
  { id: "all", label: "ALL", f: {} },
  { id: "small", label: "SMALL PATCHES", f: { type: "small" } },
  { id: "major", label: "MAJOR UPDATES", f: { type: "major" } },
  { id: "possible", label: "POSSIBLE", f: { status: "possible" } },
  { id: "strong", label: "STRONG UPDATE SIGNAL", f: { status: "strong" } },
  { id: "confirmed", label: "CONFIRMED", f: { status: "confirmed" } }
];
const PAGE_SIZE = 30;

function UpdateHistory({
  mode,
  region,
  refreshKey,
  onWhy,
  externalSizeFilter,
  onClearExternalSizeFilter
}) {
  const [tab, setTab] = useState("all");
  const [filterRegion, setFilterRegion] = useState(region);
  const [searchInput, setSearchInput] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const [versionFilter, setVersionFilter] = useState("");
  const [sourceFilter, setSourceFilter] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [sizeFilter, setSizeFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [events, setEvents] = useState(null);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState(null);
  const [limit, setLimit] = useState(PAGE_SIZE);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    setFilterRegion(region);
  }, [region]);

  useEffect(() => {
    if (externalSizeFilter) {
      setSizeFilter(externalSizeFilter);
      setShowFilters(true);
    }
  }, [externalSizeFilter]);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(searchInput.trim()), 350);
    return () => clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    let cancelled = false;
    const tabParams = HISTORY_TABS.find((t) => t.id === tab).f;
    const params = {
      region: filterRegion,
      q: debouncedQuery,
      version: versionFilter.trim(),
      source: sourceFilter,
      from: fromDate,
      to: toDate,
      size: sizeFilter,
      limit,
      ...tabParams
    };
    if (typeFilter && !tabParams.type) {
      params.type = typeFilter;
    }

    const promise =
      mode === "demo"
        ? Promise.resolve(queryDemoHistory(params))
        : api.history(params, refreshKey || undefined);

    promise
      .then((res) => {
        if (!cancelled) {
          setEvents(res.events);
          setTotal(res.total);
          setError(null);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setEvents(null);
          setError(err.message);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [
    mode,
    tab,
    filterRegion,
    debouncedQuery,
    versionFilter,
    sourceFilter,
    fromDate,
    toDate,
    sizeFilter,
    typeFilter,
    limit,
    refreshKey
  ]);

  const resetFilters = () => {
    setSearchInput("");
    setVersionFilter("");
    setSourceFilter("");
    setFromDate("");
    setToDate("");
    setSizeFilter("");
    setTypeFilter("");
    setFilterRegion(region);
    setTab("all");
    if (onClearExternalSizeFilter) onClearExternalSizeFilter();
  };

  return (
    <section className="history panel" aria-labelledby="hist-title">
      <div className="panel-head">
        <h2 id="hist-title" className="panel-title">
          📜 Update History
        </h2>
        <span className="muted small">
          {events ? `${total} event${total === 1 ? "" : "s"}` : ""}
        </span>
      </div>

      <div className="tabs" role="tablist">
        {HISTORY_TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={tab === t.id ? "active" : ""}
            onClick={() => {
              setTab(t.id);
              setLimit(PAGE_SIZE);
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="filters">
        <input
          type="search"
          placeholder="Search evidence, source, app, reason…"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          aria-label="Search history"
        />
        <button
          className="link"
          onClick={() => setShowFilters((s) => !s)}
          aria-expanded={showFilters}
        >
          {showFilters ? "Hide filters" : "More filters"}
        </button>
      </div>

      {showFilters && (
        <div className="filter-grid">
          <label>
            Region
            <select
              value={filterRegion}
              onChange={(e) => setFilterRegion(e.target.value)}
            >
              <option value="all">All regions</option>
              {REGIONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </label>
          <label>
            Source
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
            >
              <option value="">All sources</option>
              <option value="google-play">Google Play</option>
              <option value="app-store">App Store (iTunes)</option>
              <option value="garena-news">Official Garena News</option>
              <option value="youtube">Official YouTube</option>
            </select>
          </label>
          <label>
            Version
            <input
              value={versionFilter}
              onChange={(e) => setVersionFilter(e.target.value)}
              placeholder="e.g. 2.132"
              maxLength={30}
            />
          </label>
          <label>
            From
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
            />
          </label>
          <label>
            To
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
            />
          </label>
          <label>
            Patch size
            <select
              value={sizeFilter}
              onChange={(e) => setSizeFilter(e.target.value)}
            >
              <option value="">Any</option>
              <option value="2-3mb">2–3 MB (hotfix)</option>
              <option value="5mb">5 MB (mini patch)</option>
              <option value="10mb">10 MB (small patch)</option>
              <option value="20mb">20 MB (resource pack)</option>
              <option value="other">Other stated size</option>
              <option value="known">Any known size</option>
              <option value="unknown">Size unknown</option>
            </select>
          </label>
          <label>
            Type
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
            >
              <option value="">Any</option>
              {Object.entries(PATCH_TYPES).map(([k, label]) => (
                <option key={k} value={k}>
                  {label}
                </option>
              ))}
            </select>
          </label>
          <button className="link" onClick={resetFilters}>
            Reset filters
          </button>
        </div>
      )}

      {error && (
        <p className="muted">
          History is unavailable ({error}). No local or sample events are substituted.
        </p>
      )}

      {!error && events === null && (
        <div className="sk-list">
          <div className="sk-block short" />
          <div className="sk-block short" />
        </div>
      )}

      {events && events.length === 0 && (
        <div className="empty">
          <div className="empty-icon">⚪</div>
          <p>
            <strong>No events match.</strong>
          </p>
          <p className="muted small">
            {mode === "real"
              ? "History only contains changes actually observed in public sources since monitoring began. The first pass records a baseline, and new events appear when a public source changes."
              : "No demo events match these filters."}
          </p>
        </div>
      )}

      {events && events.length > 0 && (
        <ul className="events">
          {events.map((ev, idx) => (
            <li
              key={ev.id}
              className={`event st-${ev.status}`}
              style={{ animationDelay: `${Math.min(idx, 8) * 40}ms` }}
            >
              <div className="ev-top">
                <span className={`chip st-${ev.status}`}>
                  {SIGNAL_DOTS[ev.status]} {SIGNAL_LABELS[ev.status] ?? ev.status}
                </span>
                <span className="chip type">
                  {PATCH_TYPES[ev.patch_type] ?? ev.patch_type}
                </span>
                {ev.size_bucket && (
                  <span className="chip size-badge">
                    {SMALL_PATCH_BUCKETS.find((b) => b.id === ev.size_bucket)?.label ??
                      ev.size_bucket}
                  </span>
                )}
                {Boolean(ev.is_global) && <span className="chip">Global source</span>}
              </div>
              <p className="ev-title">
                {ev.app}
                {ev.new_version
                  ? ` · ${
                      ev.old_version && ev.old_version !== ev.new_version
                        ? `${ev.old_version} → `
                        : ""
                    }${ev.new_version}`
                  : ""}
              </p>
              <p className="ev-reason">{ev.evidence}</p>
              <dl className="ev-facts">
                <div>
                  <dt>📦</dt>
                  <dd>{ev.size ?? SIZE_UNKNOWN_LABEL}</dd>
                </div>
                <div>
                  <dt>🔄</dt>
                  <dd>{ev.new_version ?? "No version"}</dd>
                </div>
                <div>
                  <dt>🕐</dt>
                  <dd>{formatDateTime(ev.timestamp)}</dd>
                </div>
                <div>
                  <dt>🌍</dt>
                  <dd>{ev.region}</dd>
                </div>
                <div>
                  <dt>📡</dt>
                  <dd>{ev.source}</dd>
                </div>
              </dl>
              <button className="btn-why sm" onClick={() => onWhy(ev)}>
                WHY DID WE DETECT THIS?
              </button>
            </li>
          ))}
        </ul>
      )}

      {events && events.length < total && (
        <button className="btn-more" onClick={() => setLimit((l) => l + PAGE_SIZE)}>
          Load more
        </button>
      )}
    </section>
  );
}

function SourceStatus({ sources, error, now, region }) {
  const [regionalOnly, setRegionalOnly] = useState(true);
  const filtered =
    sources?.filter((s) => !regionalOnly || s.region === region || s.global) ?? null;

  return (
    <section className="sources panel" aria-labelledby="src-title">
      <div className="panel-head">
        <h2 id="src-title" className="panel-title">
          📡 Source Status
        </h2>
        <label className="inline">
          <input
            type="checkbox"
            checked={regionalOnly}
            onChange={(e) => setRegionalOnly(e.target.checked)}
          />{" "}
          {region} + global only
        </label>
      </div>

      {error && (
        <p className="muted">
          Source availability could not be retrieved ({error}). The source list is not
          inferred.
        </p>
      )}

      {filtered && (
        <div className="src-groups">
          {Object.keys(SOURCE_GROUP_TITLES).map((family) => {
            const items = filtered.filter((s) => s.family === family);
            if (!items.length) return null;
            return (
              <div key={family} className="src-group">
                <h4>{SOURCE_GROUP_TITLES[family]}</h4>
                <ul>
                  {items.map((src) => {
                    const meta = SOURCE_STATE_META[src.state] ?? SOURCE_STATE_META.pending;
                    return (
                      <li key={src.key} className={`src s-${src.state}`}>
                        <div className="src-row">
                          <span className="src-dot" title={meta.label}>
                            {meta.dot}
                          </span>
                          <a
                            href={src.url}
                            target="_blank"
                            rel="noreferrer"
                            className="src-label"
                          >
                            {src.label}
                          </a>
                          <span className="src-state">
                            {meta.label}
                            {src.latency_ms
                              ? ` · ${(src.latency_ms / 1000).toFixed(1)}s`
                              : ""}
                            {src.poll_interval_min
                              ? ` · poll ${src.poll_interval_min}m`
                              : ""}
                          </span>
                        </div>
                        <div className="src-meta">
                          <span>
                            Last success: {formatRelativePast(src.last_success, now)}
                          </span>
                          <span>
                            Last change:{" "}
                            {src.last_change_at
                              ? formatRelativePast(src.last_change_at, now)
                              : "none detected"}
                          </span>
                          {src.summary && (
                            <span className="src-summary">
                              Last response: {src.summary}
                            </span>
                          )}
                          {src.last_error && (
                            <span className="src-err">
                              Last error
                              {src.last_error_at
                                ? ` (${formatRelativePast(src.last_error_at, now)})`
                                : ""}
                              : {src.last_error}
                            </span>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>
      )}

      <p className="card-foot">
        ⚫ Not listed means the storefront returned no public listing for that app in that
        country — it is a verified storefront result, not a network error.
      </p>
    </section>
  );
}

const SCHEMA_SQL_SNIPPET = `-- migrations/0001_init.sql (Cloudflare D1 & Local SQLite)
CREATE TABLE IF NOT EXISTS sources_state (
  key TEXT PRIMARY KEY,
  family TEXT NOT NULL,
  label TEXT NOT NULL,
  region TEXT NOT NULL,
  is_global INTEGER NOT NULL DEFAULT 0,
  app TEXT,
  platform TEXT,
  url TEXT NOT NULL,
  poll_interval_min INTEGER NOT NULL DEFAULT 20,
  state TEXT NOT NULL DEFAULT 'pending',
  version TEXT,
  updated_date TEXT,
  file_size_bytes INTEGER,
  release_notes_hash TEXT,
  content_hash TEXT,
  latest_item_id TEXT,
  summary TEXT,
  note TEXT,
  last_checked TEXT,
  last_success TEXT,
  last_error TEXT,
  last_error_at TEXT,
  last_change_at TEXT,
  last_change TEXT,
  latency_ms INTEGER,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  raw_snapshot TEXT
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  dedup_key TEXT NOT NULL UNIQUE,
  timestamp TEXT NOT NULL,
  region TEXT NOT NULL,
  app TEXT NOT NULL,
  kind TEXT NOT NULL,
  patch_type TEXT NOT NULL,
  status TEXT NOT NULL,
  classification_label TEXT NOT NULL,
  classification_reason TEXT NOT NULL,
  old_version TEXT,
  new_version TEXT,
  size TEXT,
  size_mb REAL,
  size_bucket TEXT,
  size_basis TEXT NOT NULL DEFAULT 'unavailable',
  source_key TEXT NOT NULL,
  source_family TEXT NOT NULL,
  source TEXT NOT NULL,
  source_url TEXT NOT NULL,
  evidence TEXT NOT NULL,
  evidence_detail TEXT,
  is_global INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);`;

const WINDOWS_DEPLOY_SNIPPET = `# === 1. Run Locally on Windows (PowerShell) ===
cd ff-small-patch-tracker
copy .env.example .env
npm install
npm run build
npm run seed
npm test
npm start
# Open http://localhost:8788 in your browser

# === 2. GitHub & Free Cloudflare Workers + D1 + Cron Deployment ===
git init
git add .
git commit -m "Recover FF Small Patch Tracker with D1 backend"
git branch -M main
git remote add origin https://github.com/<your-username>/ff-small-patch-tracker.git
git push -u origin main

npx wrangler login
npx wrangler d1 create ff-patch-tracker-db
# Paste the returned database_id into wrangler.toml under [[d1_databases]]
npm run cf:d1:migrate:remote
npm run cf:deploy`;

function BackendStudioPanel({ region, mode, onRefresh }) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("testbench");
  const [simNotice, setSimNotice] = useState(null);
  const [busy, setBusy] = useState(false);

  const triggerScenario = async (scenario, label) => {
    if (busy) return;
    setBusy(true);
    setSimNotice(`Running backend classifier for: ${label} (${region})…`);
    try {
      const res = await api.simulateSignal({ region, scenario });
      setSimNotice(
        res.changed
          ? `✅ Recorded new ${res.event?.classification_label || ""} observation for ${region}: ${
              res.event?.evidence || label
            }`
          : `ℹ️ Duplicate-event prevention active: identical observation was already recorded.`
      );
      if (onRefresh) await onRefresh(Date.now());
    } catch (err) {
      setSimNotice(`⚠️ Could not run scenario: ${err.message}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="studio panel" aria-labelledby="studio-title">
      <div className="panel-head">
        <h2 id="studio-title" className="panel-title">
          🛠️ Backend, Database &amp; Free-Tier Deployment Studio
        </h2>
        <button
          className="link"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
        >
          {open ? "Hide studio" : "Open Backend Testbench & Deployment Guide"}
        </button>
      </div>

      <p className="muted small" style={{ margin: 0 }}>
        Verify small-patch signal classification (<code>2–3 MB</code>, <code>5 MB</code>,{" "}
        <code>10 MB</code>, <code>20 MB</code>, <code>STRONG UPDATE SIGNAL</code>,{" "}
        <code>CONFIRMED</code>) in real time or inspect the SQLite / Cloudflare D1 schema and
        Windows setup commands.
      </p>

      {open && (
        <div style={{ marginTop: "12px" }}>
          <div className="tabs" role="tablist">
            {[
              { id: "testbench", label: "🧪 LIVE SIGNAL TESTBENCH" },
              { id: "schema", label: "🗄️ D1 / SQLITE SCHEMA" },
              { id: "deploy", label: "🚀 WINDOWS & CLOUDFLARE DEPLOY" }
            ].map((t) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={activeTab === t.id}
                className={activeTab === t.id ? "active" : ""}
                onClick={() => setActiveTab(t.id)}
              >
                {t.label}
              </button>
            ))}
          </div>

          {activeTab === "testbench" && (
            <div>
              <p className="small">
                Inject a real observation into the backend classifier for{" "}
                <strong>{region}</strong> (works in <strong>REAL MONITORING</strong> mode) and
                verify how the radar, timeline, and deduplicator respond:
              </p>
              <div className="studio-actions">
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() => triggerScenario("2-3mb", "2–3 MB Hotfix Announcement")}
                >
                  + 2–3 MB Hotfix Signal ({region})
                </button>
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() => triggerScenario("5mb", "5 MB Mini Balance Patch")}
                >
                  + 5 MB Mini Patch ({region})
                </button>
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() => triggerScenario("10mb", "10 MB Gameplay Patch")}
                >
                  + 10 MB Small Patch ({region})
                </button>
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() => triggerScenario("20mb", "20 MB Event & Voice Pack")}
                >
                  + 20 MB Resource Pack ({region})
                </button>
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() =>
                    triggerScenario("strong_metadata", "Store Listing Date Change")
                  }
                >
                  + Store Metadata Change → STRONG SIGNAL ({region})
                </button>
                <button
                  type="button"
                  className="btn-sim"
                  disabled={busy || mode === "demo"}
                  onClick={() =>
                    triggerScenario("confirmed_version", "Store Version Increment")
                  }
                >
                  + Store Version Bump → CONFIRMED ({region})
                </button>
              </div>
              {mode === "demo" && (
                <p className="muted small">
                  Switch from DEMO MODE to REAL MONITORING in the top bar to test live backend
                  signal injection.
                </p>
              )}
              {simNotice && <div className="banner info small">{simNotice}</div>}
            </div>
          )}

          {activeTab === "schema" && (
            <div>
              <p className="small">
                SQLite / Cloudflare D1 migration (<code>migrations/0001_init.sql</code>) with
                unique deduplication keys and indexed regional/size queries:
              </p>
              <pre className="code-box">{SCHEMA_SQL_SNIPPET}</pre>
            </div>
          )}

          {activeTab === "deploy" && (
            <div>
              <p className="small">
                Exact commands to run locally on Windows PowerShell and deploy to Cloudflare
                Workers + D1 + Cron Triggers (Free Tier):
              </p>
              <pre className="code-box">{WINDOWS_DEPLOY_SNIPPET}</pre>
            </div>
          )}
        </div>
      )}
    </section>
  );
}

function WhyModal({ event, onClose }) {
  const dialogRef = useRef(null);

  useEffect(() => {
    const el = dialogRef.current;
    if (el && !el.open && typeof el.showModal === "function") {
      el.showModal();
    }
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const isDemo = event.source_url === "#demo";
  const detailObj =
    typeof event.evidence_detail === "string"
      ? (() => {
          try {
            return JSON.parse(event.evidence_detail);
          } catch {
            return { raw: event.evidence_detail };
          }
        })()
      : event.evidence_detail;

  return (
    <dialog
      ref={dialogRef}
      className="modal"
      onClose={onClose}
      onClick={(e) => e.target === dialogRef.current && onClose()}
    >
      <div className="modal-body">
        <div className="modal-head">
          <h2>WHY DID WE DETECT THIS?</h2>
          <button className="link" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        {isDemo && (
          <p className="banner demo small">
            DEMO MODE — this is fictional sample evidence.
          </p>
        )}

        <dl className="why">
          <div>
            <dt>Classification &amp; Reason</dt>
            <dd>
              <strong>
                {SIGNAL_DOTS[event.status]} {SIGNAL_LABELS[event.status] ?? event.status}
              </strong>
              <br />
              {event.classification_reason ??
                (event.status === "confirmed"
                  ? "Directly verified by a public storefront version increment."
                  : "Classified from public metadata change.")}
            </dd>
          </div>
          <div>
            <dt>Source</dt>
            <dd>
              {isDemo ? (
                event.source
              ) : (
                <a href={event.source_url} target="_blank" rel="noreferrer">
                  {event.source}
                </a>
              )}
              <br />
              <code>{event.source_url}</code>
            </dd>
          </div>
          <div>
            <dt>Supporting Evidence</dt>
            <dd>{event.evidence}</dd>
          </div>
          <div>
            <dt>Observation Time</dt>
            <dd>
              {formatDateTime(event.timestamp)} <code>{event.timestamp}</code>
            </dd>
          </div>
          <div>
            <dt>Region</dt>
            <dd>
              {event.region}
              {event.is_global
                ? " (global source — not proof of a regional rollout)"
                : ""}
            </dd>
          </div>
          <div>
            <dt>Patch type</dt>
            <dd>{PATCH_TYPES[event.patch_type] ?? event.patch_type}</dd>
          </div>
          <div>
            <dt>Versions</dt>
            <dd>
              {event.old_version ?? "—"} → {event.new_version ?? "—"}
            </dd>
          </div>
          <div>
            <dt>Observed Patch Size &amp; Basis</dt>
            <dd>
              <strong>{event.size ?? SIZE_UNKNOWN_LABEL}</strong>
              <br />
              <span className="muted small">
                Basis: {SIZE_BASIS_LABELS[event.size_basis] ?? SIZE_BASIS_LABELS.unavailable}
              </span>
            </dd>
          </div>
        </dl>

        {detailObj && !isDemo && (
          <details>
            <summary>Raw observation</summary>
            <pre>{JSON.stringify(detailObj, null, 2)}</pre>
          </details>
        )}

        <p className="muted small">
          {event.status === "confirmed"
            ? "CONFIRMED means a public store listing or official release note for this region directly verified the update."
            : "This is an unconfirmed signal, kept separate from confirmed releases. It reports an observed public change only."}
        </p>
      </div>
    </dialog>
  );
}

function getInitialMode() {
  const param = new URLSearchParams(window.location.search).get("demo");
  if (param === "1") return "demo";
  if (param === "0") return "real";
  return safeStorageGet("ff-mode", "real") === "demo" ? "demo" : "real";
}

function getInitialRegion() {
  const saved = safeStorageGet("ff-region", "India");
  return REGIONS.includes(saved) ? saved : "India";
}

const AUTO_REFRESH_MS = 2 * 60 * 1000;

export default function App() {
  const [mode, setMode] = useState(getInitialMode);
  const [region, setRegion] = useState(getInitialRegion);
  const [status, setStatus] = useState(null);
  const [statusError, setStatusError] = useState(null);
  const [sources, setSources] = useState(null);
  const [sourcesError, setSourcesError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [checkProgress, setCheckProgress] = useState([]);
  const [checking, setChecking] = useState(false);
  const [cooldownSec, setCooldownSec] = useState(0);
  const [whyEvent, setWhyEvent] = useState(null);
  const [externalSizeFilter, setExternalSizeFilter] = useState("");
  const [now, setNow] = useState(Date.now());
  const reqCounter = useRef(0);

  useEffect(() => {
    safeStorageSet("ff-mode", mode);
  }, [mode]);

  useEffect(() => {
    safeStorageSet("ff-region", region);
  }, [region]);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (cooldownSec <= 0) return;
    const timer = setInterval(() => {
      setCooldownSec((s) => (s <= 1 ? 0 : s - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldownSec]);

  const loadDashboard = useCallback(
    async (cacheBust) => {
      const reqId = ++reqCounter.current;
      if (mode === "demo") {
        setStatus(buildDemoStatus(region));
        setSources(buildDemoSources());
        setStatusError(null);
        setSourcesError(null);
        setLoading(false);
        return;
      }
      const [stRes, srcRes] = await Promise.allSettled([
        api.status(region, cacheBust),
        api.sources(cacheBust)
      ]);
      if (reqId === reqCounter.current) {
        if (stRes.status === "fulfilled") {
          setStatus(stRes.value);
          setStatusError(null);
        } else {
          setStatus(null);
          setStatusError(stRes.reason?.message ?? "Status unavailable");
        }
        if (srcRes.status === "fulfilled") {
          setSources(srcRes.value);
          setSourcesError(null);
        } else {
          setSources(null);
          setSourcesError(srcRes.reason?.message ?? "Sources unavailable");
        }
        setLoading(false);
      }
    },
    [mode, region]
  );

  useEffect(() => {
    setLoading(true);
    setStatus(null);
    loadDashboard();
  }, [loadDashboard]);

  useEffect(() => {
    if (mode !== "real") return;
    const tick = () => {
      if (document.visibilityState === "visible") {
        loadDashboard();
        setRefreshKey((k) => k + 1);
        pollNotificationsForRegion(region).catch(() => {});
      }
    };
    pollNotificationsForRegion(region).catch(() => {});
    const timer = setInterval(tick, AUTO_REFRESH_MS);
    const onVis = () => document.visibilityState === "visible" && tick();
    document.addEventListener("visibilitychange", onVis);
    return () => {
      clearInterval(timer);
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [mode, region, loadDashboard]);

  const handleManualCheck = async () => {
    if (checking || cooldownSec > 0) return;
    setChecking(true);
    setCheckProgress([{ type: "start", total: 0, message: "Checking public sources…" }]);
    const pushEvent = (evt) => setCheckProgress((prev) => [...prev, evt]);
    try {
      const res =
        mode === "demo" ? await runDemoCheck(pushEvent) : await api.check(pushEvent);
      if (res?.rateLimited && res.retryAfterSeconds) {
        setCooldownSec(res.retryAfterSeconds);
      } else if (mode === "real") {
        setCooldownSec(15);
      }
    } catch (err) {
      pushEvent({
        type: "error",
        message: `Check could not be completed: ${err.message}. Nothing was substituted.`
      });
    } finally {
      const bust = Date.now();
      await loadDashboard(bust);
      setRefreshKey((k) => k + 1);
      if (mode === "real") {
        pollNotificationsForRegion(region).catch(() => {});
      }
      setChecking(false);
    }
  };

  const showUnavailableBanner =
    mode === "real" && (statusError || status?.monitoring?.state === "unavailable");

  return (
    <div className={`app mode-${mode}`}>
      <div className="grain" aria-hidden="true" />

      <header className="topbar">
        <div className="brand">
          <img src="/favicon.svg" alt="" width={34} height={34} />
          <div>
            <div className="brand-kicker">🎮 Free Fire · public evidence only</div>
            <h1>FF Small Patch Tracker</h1>
          </div>
        </div>

        <div className="topbar-actions">
          <button
            className={`mode-badge ${mode}`}
            onClick={() => setMode(mode === "real" ? "demo" : "real")}
            title="Switch between real monitoring and clearly-labelled demo data"
          >
            <span className="pulse" />
            {mode === "real" ? "REAL MONITORING" : "DEMO MODE"}
            <span className="mode-switch">switch</span>
          </button>

          <button
            className="btn-check"
            onClick={handleManualCheck}
            disabled={checking || cooldownSec > 0}
          >
            {checking
              ? "Checking…"
              : cooldownSec > 0
              ? `WAIT ${cooldownSec}s`
              : "CHECK NOW"}
          </button>
        </div>
      </header>

      <nav className="regions" aria-label="Region">
        <span className="regions-label">🌍 Region</span>
        {REGIONS.map((r) => (
          <button
            key={r}
            className={r === region ? "active" : ""}
            onClick={() => setRegion(r)}
            aria-pressed={r === region}
          >
            {r}
          </button>
        ))}
      </nav>

      {mode === "demo" && (
        <div className="banner demo">
          DEMO MODE — every value on this screen is fictional sample data. Nothing is
          fetched or stored. Switch to REAL MONITORING for live results.
        </div>
      )}

      {showUnavailableBanner && (
        <div className="banner warn" role="alert">
          ⚠️ Monitoring temporarily unavailable.{" "}
          {statusError
            ? "The monitoring API did not respond."
            : status?.monitoring?.message}{" "}
          No substitute data is shown.
        </div>
      )}

      {checkProgress.length > 0 && (
        <CheckProgressPanel
          progress={checkProgress}
          checking={checking}
          onClose={() => setCheckProgress([])}
        />
      )}

      <main className="grid">
        <UpdateRadar
          status={status}
          loading={loading}
          error={statusError}
          now={now}
          onWhy={setWhyEvent}
          mode={mode}
          onSelectSizeBucket={(bucketId) => setExternalSizeFilter(bucketId)}
        />

        <div className="cards">
          <CurrentVersionCard status={status} loading={loading} />
          <LatestPatchCard status={status} loading={loading} onWhy={setWhyEvent} />
          <MonitoringStatusCard
            status={status}
            loading={loading}
            now={now}
            error={statusError}
          />
          <NotificationsCard mode={mode} region={region} />
        </div>

        <UpdateHistory
          mode={mode}
          region={region}
          refreshKey={refreshKey}
          onWhy={setWhyEvent}
          externalSizeFilter={externalSizeFilter}
          onClearExternalSizeFilter={() => setExternalSizeFilter("")}
        />

        <SourceStatus
          sources={sources}
          error={sourcesError}
          now={now}
          region={region}
        />

        <BackendStudioPanel
          region={region}
          mode={mode}
          onRefresh={async (bust) => {
            await loadDashboard(bust);
            setRefreshKey((k) => k + 1);
          }}
        />
      </main>

      <footer className="foot">
        <p>
          <strong>Important limitation.</strong> This tracker cannot see Garena&apos;s
          private release schedule, internal servers or in-game download manifests. It
          reports only changes observed in public sources: official Garena news, official
          YouTube channels and public store listings. A signal is not a prediction, and
          patch sizes are shown only when a public source states them (otherwise shown as
          &ldquo;{SIZE_UNKNOWN_LABEL}&rdquo;).
        </p>
        <p className="foot-meta">
          FF Small Patch Tracker is an unofficial fan tool and is not affiliated with
          Garena.
        </p>
      </footer>

      {whyEvent && <WhyModal event={whyEvent} onClose={() => setWhyEvent(null)} />}
    </div>
  );
}
