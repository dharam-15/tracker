import { api } from "./api.js";

const KEY_ENABLED = "ff-notify-enabled";
const KEY_LEVELS = "ff-notify-levels";
const keyLastSeen = (region) => `ff-notify-last:${region}`;

function safeGet(key, fallback = null) {
  try {
    return localStorage.getItem(key) ?? fallback;
  } catch {
    return fallback;
  }
}

function safeSet(key, val) {
  try {
    localStorage.setItem(key, val);
  } catch {
    // ignore storage errors in sandboxed contexts
  }
}

export const isNotificationSupported = () =>
  typeof window !== "undefined" && "Notification" in window;

export const isNotificationEnabled = () =>
  isNotificationSupported() &&
  safeGet(KEY_ENABLED) === "1" &&
  Notification.permission === "granted";

export const getNotificationLevels = () => {
  try {
    return JSON.parse(safeGet(KEY_LEVELS, '["strong","confirmed"]'));
  } catch {
    return ["strong", "confirmed"];
  }
};

export const setNotificationLevels = (levels) =>
  safeSet(KEY_LEVELS, JSON.stringify(levels));

export async function requestNotificationPermission() {
  if (!isNotificationSupported()) return "unsupported";
  const perm =
    Notification.permission === "default"
      ? await Notification.requestPermission()
      : Notification.permission;
  safeSet(KEY_ENABLED, perm === "granted" ? "1" : "0");
  return perm;
}

export function disableNotifications() {
  safeSet(KEY_ENABLED, "0");
}

export async function showEventNotification(ev) {
  const title =
    ev.status === "confirmed"
      ? "✅ Free Fire patch confirmed"
      : "🔔 Free Fire update signal detected";
  const options = {
    body: `${ev.region} · ${ev.app}${ev.new_version ? ` ${ev.new_version}` : ""} — ${
      ev.classification_label ?? ev.status
    } · ${ev.source}`,
    tag: `ff-event-${ev.id}`,
    icon: "/icon-192.png",
    badge: "/icon-192.png"
  };
  const reg = await navigator.serviceWorker?.getRegistration().catch(() => null);
  if (reg && reg.showNotification) {
    await reg.showNotification(title, options);
  } else {
    new Notification(title, options);
  }
}

export async function pollNotificationsForRegion(region) {
  if (!isNotificationEnabled()) return;
  const sinceId = Number(safeGet(keyLastSeen(region), "0"));
  const { events, latestId } = await api.notifications(
    region,
    sinceId,
    getNotificationLevels()
  );
  for (const ev of events.slice(0, 3)) {
    await showEventNotification(ev);
  }
  if (latestId) {
    safeSet(keyLastSeen(region), String(latestId));
  }
}

export async function sendTestNotification() {
  const reg = await navigator.serviceWorker?.getRegistration().catch(() => null);
  const options = {
    body: "Notifications are working. You'll only be alerted for meaningful new signals.",
    icon: "/icon-192.png",
    tag: "ff-test"
  };
  if (reg && reg.showNotification) {
    await reg.showNotification("FF Small Patch Tracker", options);
  } else {
    new Notification("FF Small Patch Tracker", options);
  }
}
