import {
  SIGNAL_WINDOW_HOURS,
  NO_SIGNAL_HEADLINE,
  SIGNAL_LABELS,
  SOURCE_FAMILIES
} from "./constants.js";

export function filterWindowEvents(region, events, now = new Date(), windowHours = SIGNAL_WINDOW_HOURS) {
  const cutoff = now.getTime() - windowHours * 3600 * 1000;
  return events.filter(
    (ev) => new Date(ev.timestamp).getTime() >= cutoff && (ev.region === region || ev.is_global)
  );
}

export function classifySignalLevel(region, windowEvents) {
  if (!windowEvents.length) return "none";
  const regional = windowEvents.filter((ev) => ev.region === region);
  if (regional.some((ev) => ev.kind === "version_change" && ev.status === "confirmed")) {
    return "confirmed";
  }
  const families = new Set(windowEvents.map((ev) => ev.source_family));
  if (regional.length && (families.size >= 2 || regional.some((ev) => ev.status === "strong"))) {
    return "strong";
  }
  return "possible";
}

export function buildTimeline(windowEvents, level) {
  const findFirst = (pred) => windowEvents.find(pred) ?? null;
  const announcement = findFirst((e) => e.kind === "official_post" || e.kind === "official_video");
  const metadata = findFirst((e) => e.kind === "listing_change");
  const version = findFirst((e) => e.kind === "version_change");
  const step = (key, label, ev, reached = Boolean(ev)) => ({
    key,
    label,
    reached,
    at: reached && ev ? ev.timestamp : null,
    detail: reached && ev ? `${ev.source}${ev.new_version ? ` · ${ev.new_version}` : ""}` : null
  });
  return [
    step("announcement", "Public announcement", announcement),
    step("metadata", "Metadata change", metadata),
    step("version", "Version change", version),
    step("confirmed", "Update confirmed", version, level === "confirmed")
  ];
}

export function evaluateSignal(region, events, now = new Date()) {
  const windowEvents = filterWindowEvents(region, events, now).sort((a, b) =>
    a.timestamp.localeCompare(b.timestamp)
  );
  const level = classifySignalLevel(region, windowEvents);
  const regional = windowEvents.filter((ev) => ev.region === region);
  const globalOnly = !regional.length && windowEvents.length > 0;
  const familyNames = [
    ...new Set(windowEvents.map((ev) => SOURCE_FAMILIES[ev.source_family] ?? ev.source_family))
  ];
  const latestConfirmed = [...regional]
    .reverse()
    .find((ev) => ev.kind === "version_change" && ev.status === "confirmed");

  let headline;
  const reasons = [];

  switch (level) {
    case "confirmed":
      headline = `${
        latestConfirmed.patch_type === "small" ? "Small patch" : "Update"
      } confirmed: ${latestConfirmed.app} ${latestConfirmed.old_version} → ${
        latestConfirmed.new_version
      } (${region}).`;
      reasons.push(
        `CONFIRMED: A public store listing for ${region} directly verified a higher version number (${latestConfirmed.old_version} → ${latestConfirmed.new_version}).`
      );
      break;
    case "strong":
      headline = `Strong update signal for ${region}: ${
        familyNames.length >= 2
          ? `${familyNames.length} independent public sources changed`
          : "store release metadata changed without a version bump"
      }.`;
      reasons.push(`Independent source families with changes: ${familyNames.join(", ")}.`);
      reasons.push(
        "STRONG UPDATE SIGNAL: Multiple independent observations or store listing metadata updates support a possible small patch, but no store version bump is confirmed yet."
      );
      break;
    case "possible":
      headline = globalOnly
        ? `Possible signal from a global official source — not confirmed for ${region}.`
        : "Possible minor-update signal detected.";
      reasons.push(
        `POSSIBLE: Limited or indirect evidence from ${familyNames.join(
          ", "
        )}. Single-source or global hints are kept separate from confirmed updates.`
      );
      break;
    default:
      headline = NO_SIGNAL_HEADLINE;
      reasons.push(
        `NO SIGNAL: No qualifying update evidence was detected in monitored public sources for ${region} during the last ${SIGNAL_WINDOW_HOURS} hours. ("No signal" does not mean an in-game update is impossible.)`
      );
  }

  for (const ev of [...windowEvents].reverse().slice(0, 6)) {
    reasons.push(
      `${ev.timestamp.slice(0, 16).replace("T", " ")} UTC · ${ev.source}: ${ev.evidence}`
    );
  }

  return {
    region,
    level,
    label: SIGNAL_LABELS[level],
    headline,
    reasons,
    evidence: [...windowEvents].reverse(),
    timeline: buildTimeline(windowEvents, level),
    windowHours: SIGNAL_WINDOW_HOURS,
    detectedAt: windowEvents[windowEvents.length - 1]?.timestamp ?? null
  };
}
