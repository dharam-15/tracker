export const REGIONS = ["India", "Bangladesh", "Indonesia", "Singapore", "Other"];
export const DEFAULT_INTERVAL_MINUTES = 20;
export const SIGNAL_WINDOW_HOURS = 72;
export const SIZE_UNKNOWN_LABEL = "Size unknown";
export const NO_SIGNAL_HEADLINE = "No reliable public signal detected.";

export const SIGNAL_LABELS = {
  none: "NO SIGNAL",
  possible: "POSSIBLE",
  strong: "STRONG UPDATE SIGNAL",
  confirmed: "CONFIRMED"
};

export const SIGNAL_DOTS = {
  none: "⚪",
  possible: "🟡",
  strong: "🟠",
  confirmed: "🟢"
};

export const SIGNAL_STRENGTH = {
  none: 0,
  possible: 1,
  strong: 2,
  confirmed: 3
};

export const PATCH_TYPES = {
  small: "Small patch",
  major: "Major update",
  maintenance: "Maintenance",
  announcement: "Announcement",
  listing: "Listing change"
};

export const SMALL_PATCH_BUCKETS = [
  { id: "2-3mb", label: "2–3 MB", range: [1.5, 3.8], desc: "Hotfix / config / event toggle" },
  { id: "5mb", label: "5 MB", range: [3.8, 7.5], desc: "Mini resource / balance tweak" },
  { id: "10mb", label: "10 MB", range: [7.5, 14.5], desc: "Small gameplay / weapon patch" },
  { id: "20mb", label: "20 MB", range: [14.5, 35.0], desc: "Event pack / voice / mode assets" },
  { id: "other", label: "Other size", range: [35.01, 5000], desc: "Larger patch or store binary delta" }
];

export const SIZE_BASIS_LABELS = {
  observed: "Directly observed in store metadata",
  reported: "Reported by official source / patch note",
  estimated: "Estimated from release scope (unconfirmed)",
  unavailable: "Size unknown (not stated by public source)"
};

export const SOURCE_FAMILIES = {
  "garena-news": "Garena official news",
  "youtube": "official YouTube channel",
  "google-play": "Google Play listing",
  "app-store": "App Store listing"
};

export const SOURCE_GROUP_TITLES = {
  "garena-news": "Official Garena news & patch notes",
  "youtube": "Official YouTube channels (Atom/RSS)",
  "google-play": "Google Play listings",
  "app-store": "App Store (iTunes Lookup API)"
};

export const SOURCE_STATE_META = {
  working: { dot: "🟢", label: "Working" },
  slow: { dot: "🟡", label: "Slow" },
  unavailable: { dot: "🔴", label: "Unavailable" },
  not_listed: { dot: "⚫", label: "Not listed" },
  pending: { dot: "⚪", label: "Not checked yet" }
};
