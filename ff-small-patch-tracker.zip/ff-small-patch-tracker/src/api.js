// FF Small Patch Tracker — Additional API endpoints for Backend Inspector & Live Testbench
const API_BASE = (typeof import.meta !== "undefined" && import.meta.env && import.meta.env.VITE_API_BASE) || "";
const apiFetch = (...args) => globalThis.fetch(...args);

async function requestJson(path, cacheBust) {
  const url = `${API_BASE}${cacheBust ? `${path}${path.includes("?") ? "&" : "?"}t=${cacheBust}` : path}`;
  const res = await apiFetch(url, { headers: { Accept: "application/json" } });
  const body = await res.json().catch(() => null);
  if (!res.ok) {
    const err = new Error(body?.error ?? `Request failed (${res.status})`);
    err.status = res.status;
    err.retryAfterSeconds = body?.retryAfterSeconds ?? null;
    throw err;
  }
  return body;
}

export const api = {
  status: (region, cacheBust) =>
    requestJson(`/api/status?region=${encodeURIComponent(region)}`, cacheBust),

  sources: (cacheBust) => requestJson("/api/sources?region=all", cacheBust),

  history: (filters, cacheBust) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(filters)) {
      if (v !== undefined && v !== "" && v !== "all") {
        params.set(k, String(v));
      }
    }
    return requestJson(`/api/history?${params.toString()}`, cacheBust);
  },

  notifications: async (region, sinceId, levels) => {
    const res = await apiFetch(`${API_BASE}/api/notifications`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ region, sinceId, levels })
    });
    if (!res.ok) throw new Error("Notifications check failed");
    return await res.json();
  },

  diagnostics: (cacheBust) => requestJson("/api/diagnostics", cacheBust),

  simulateSignal: async (payload) => {
    const res = await apiFetch(`${API_BASE}/api/simulate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const body = await res.json().catch(() => null);
    if (!res.ok) throw new Error(body?.error ?? `Simulation failed (${res.status})`);
    return body;
  },

  check: async (onEvent) => {
    const res = await apiFetch(`${API_BASE}/api/check`, { method: "POST" });
    if (res.status === 429) {
      const body = await res.json().catch(() => ({}));
      const waitSec = body.retryAfterSeconds ?? 60;
      const msg = body.error || `Rate limited: please wait ${waitSec}s before running another manual check.`;
      const evt = { type: "error", rateLimited: true, retryAfterSeconds: waitSec, message: msg };
      onEvent(evt);
      return evt;
    }
    if (!res.ok || !res.body) {
      throw new Error(`Check request failed (${res.status})`);
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let lastEvent = null;

    for (;;) {
      const { value, done } = await reader.read();
      if (value) buffer += decoder.decode(value, { stream: true });
      let newlineIdx;
      while ((newlineIdx = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, newlineIdx).trim();
        buffer = buffer.slice(newlineIdx + 1);
        if (line) {
          try {
            lastEvent = JSON.parse(line);
            onEvent(lastEvent);
          } catch {
            // ignore malformed chunk
          }
        }
      }
      if (done) break;
    }

    if (!lastEvent || (lastEvent.type !== "complete" && lastEvent.type !== "error")) {
      throw new Error("Check ended unexpectedly");
    }
    return lastEvent;
  }
};
