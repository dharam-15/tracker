import { REGIONS, DEFAULT_INTERVAL_MINUTES, SIGNAL_LABELS } from "./constants.js";
import { evaluateSignal } from "./signal.js";

const HOUR_MS = 3600 * 1000;
const hoursAgoIso = (h) => new Date(Date.now() - h * HOUR_MS).toISOString();

let nextDemoId = 1;
function makeDemoEvent(overrides, hoursAgo) {
  const status = overrides.status || "possible";
  return {
    id: nextDemoId++,
    timestamp: hoursAgoIso(hoursAgo),
    app: "Free Fire MAX",
    old_version: null,
    new_version: null,
    size: null,
    size_mb: null,
    size_bucket: null,
    size_basis: "unavailable",
    classification_label: SIGNAL_LABELS[status],
    classification_reason:
      status === "confirmed"
        ? "Public store listing shows a verified higher version number."
        : status === "strong"
        ? "Store listing metadata timestamp updated without version bump."
        : "Single public source changed; unconfirmed signal.",
    source: `DEMO · ${overrides.source_family}`,
    source_url: "#demo",
    evidence_detail: { demo: true },
    is_global: false,
    created_at: hoursAgoIso(hoursAgo),
    ...overrides
  };
}

export const DEMO_EVENTS = [
  makeDemoEvent(
    {
      region: "Indonesia",
      kind: "official_post",
      patch_type: "small",
      status: "possible",
      source_family: "garena-news",
      source: "DEMO · Garena Official News · Indonesia",
      size: "2.5 MB (reported by source)",
      size_mb: 2.5,
      size_bucket: "2-3mb",
      size_basis: "reported",
      evidence:
        'DEMO: New official post "Patch Notes: Event Hotfix Demo" (category: Patch Note) appeared.'
    },
    30
  ),
  makeDemoEvent(
    {
      region: "Indonesia",
      kind: "listing_change",
      patch_type: "listing",
      status: "strong",
      source_family: "google-play",
      source: "DEMO · Google Play · Free Fire MAX · ID",
      old_version: "2.132.1",
      new_version: "2.132.1",
      evidence:
        "DEMO: Listing date changed from Sep 9 to Oct 1 while the version stayed 2.132.1."
    },
    20
  ),
  makeDemoEvent(
    {
      region: "Indonesia",
      kind: "version_change",
      patch_type: "small",
      status: "confirmed",
      source_family: "google-play",
      source: "DEMO · Google Play · Free Fire MAX · ID",
      old_version: "2.132.1",
      new_version: "2.132.2",
      size: "2.5 MB (stated in official post)",
      size_mb: 2.5,
      size_bucket: "2-3mb",
      size_basis: "reported",
      evidence:
        "DEMO: Listing now shows version 2.132.2 (previously 2.132.1). Only the last version component changed."
    },
    6
  ),
  makeDemoEvent(
    {
      region: "India",
      kind: "official_video",
      patch_type: "announcement",
      status: "possible",
      source_family: "youtube",
      source: "DEMO · YouTube · Free Fire India Official",
      size: "10 MB (estimated from mini-patch note)",
      size_mb: 10,
      size_bucket: "10mb",
      size_basis: "estimated",
      evidence: 'DEMO: New official video "Small Balance Patch Preview Demo" appeared.'
    },
    10
  ),
  makeDemoEvent(
    {
      region: "India",
      kind: "listing_change",
      patch_type: "listing",
      status: "strong",
      source_family: "google-play",
      source: "DEMO · Google Play · Free Fire MAX · IN",
      old_version: "2.132.1",
      new_version: "2.132.1",
      evidence:
        "DEMO: Listing date changed while the version stayed 2.132.1."
    },
    4
  ),
  makeDemoEvent(
    {
      region: "Bangladesh",
      kind: "listing_change",
      patch_type: "small",
      status: "possible",
      source_family: "app-store",
      app: "Free Fire",
      source: "DEMO · App Store · Free Fire · BD",
      size: "5.2 MB (reported in release notes)",
      size_mb: 5.2,
      size_bucket: "5mb",
      size_basis: "reported",
      evidence:
        "DEMO: Release-notes text changed (5.2 MB resource hotfix) while the version stayed the same."
    },
    2
  ),
  makeDemoEvent(
    {
      region: "Singapore",
      kind: "official_post",
      patch_type: "small",
      status: "possible",
      source_family: "garena-news",
      source: "DEMO · Garena Official News · Global",
      size: "20 MB (reported voice/event pack)",
      size_mb: 20,
      size_bucket: "20mb",
      size_basis: "reported",
      evidence:
        "DEMO: Official announcement mentions a 20 MB in-game voice & event resource update."
    },
    14
  ),
  makeDemoEvent(
    {
      region: "Indonesia",
      kind: "version_change",
      patch_type: "major",
      status: "confirmed",
      source_family: "app-store",
      app: "Free Fire",
      source: "DEMO · App Store · Free Fire · ID",
      old_version: "1.131.0",
      new_version: "1.132.0",
      evidence:
        "DEMO: Listing now shows version 1.132.0 (previously 1.131.0). Matches a major (OB-style) release."
    },
    480
  )
];

export function buildDemoSources() {
  const states = ["working", "working", "slow", "working", "unavailable"];
  return REGIONS.flatMap((region, rIdx) =>
    ["google-play", "app-store"].map((family, fIdx) => ({
      key: `demo:${family}:${region}`,
      family,
      label: `DEMO · ${family === "google-play" ? "Google Play" : "App Store"} · ${region}`,
      region,
      global: false,
      url: "#demo",
      poll_interval_min: family === "app-store" ? 15 : 20,
      state: fIdx === 0 ? states[rIdx] : "working",
      summary: "Demo listing",
      note: "Fictional demo source.",
      last_checked: hoursAgoIso(0.1),
      last_success: states[rIdx] === "unavailable" && fIdx === 0 ? hoursAgoIso(5) : hoursAgoIso(0.1),
      last_error: states[rIdx] === "unavailable" && fIdx === 0 ? "DEMO: Timed out" : null,
      last_error_at: states[rIdx] === "unavailable" && fIdx === 0 ? hoursAgoIso(0.1) : null,
      last_change_at: null,
      last_change: null,
      latency_ms: states[rIdx] === "slow" && fIdx === 0 ? 5200 : 640
    }))
  );
}

export function buildDemoStatus(region) {
  const regionalEvents = DEMO_EVENTS.filter((e) => e.region === region).sort((a, b) =>
    b.timestamp.localeCompare(a.timestamp)
  );
  const lastCheckDate = new Date(Date.now() - 7 * 60 * 1000);
  const regionalSources = buildDemoSources().filter((s) => s.region === region);

  return {
    mode: "DEMO MODE",
    region,
    generatedAt: new Date().toISOString(),
    signal: evaluateSignal(region, DEMO_EVENTS),
    latestPatch: regionalEvents[0] ?? null,
    latestConfirmed:
      regionalEvents.find((e) => e.status === "confirmed" && e.kind === "version_change") ?? null,
    versions: [
      {
        app: "Free Fire",
        platform: "Android",
        version: region === "India" ? null : "1.132.1",
        updated: "Demo date",
        state: region === "India" ? "not_listed" : "working",
        source_url: "#demo",
        observed_at: lastCheckDate.toISOString()
      },
      {
        app: "Free Fire MAX",
        platform: "Android",
        version: region === "Indonesia" ? "2.132.2" : "2.132.1",
        updated: "Demo date",
        state: "working",
        source_url: "#demo",
        observed_at: lastCheckDate.toISOString()
      },
      {
        app: "Free Fire MAX",
        platform: "iOS",
        version: "2.132.1",
        updated: "Demo date",
        state: "working",
        source_url: "#demo",
        observed_at: lastCheckDate.toISOString()
      }
    ],
    lastCheck: lastCheckDate.toISOString(),
    nextCheck: new Date(lastCheckDate.getTime() + DEFAULT_INTERVAL_MINUTES * 60 * 1000).toISOString(),
    intervalMinutes: DEFAULT_INTERVAL_MINUTES,
    monitoring: {
      state: "ok",
      gapMinutes: 7,
      message: "DEMO MODE — no sources are contacted and nothing is stored."
    },
    sources: {
      total: regionalSources.length,
      working: regionalSources.filter((s) => s.state === "working").length,
      slow: regionalSources.filter((s) => s.state === "slow").length,
      unavailable: regionalSources.filter((s) => s.state === "unavailable").length,
      not_listed: 0,
      pending: 0
    }
  };
}

export function queryDemoHistory(filters) {
  let list = [...DEMO_EVENTS].sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  if (filters.region && filters.region !== "all") {
    list = list.filter((e) => e.region === filters.region);
  }
  if (filters.status) {
    const allowed = filters.status.split(",");
    list = list.filter((e) => allowed.includes(e.status));
  }
  if (filters.source) {
    list = list.filter((e) => e.source_family === filters.source);
  }
  if (filters.type === "small") {
    list = list.filter((e) => e.patch_type === "small" || e.patch_type === "listing");
  } else if (filters.type) {
    const allowed = filters.type.split(",");
    list = list.filter((e) => allowed.includes(e.patch_type));
  }
  if (filters.version) {
    list = list.filter((e) =>
      `${e.old_version ?? ""} ${e.new_version ?? ""}`.includes(filters.version)
    );
  }
  if (filters.size === "known") {
    list = list.filter((e) => Boolean(e.size));
  } else if (filters.size === "unknown") {
    list = list.filter((e) => !e.size);
  } else if (filters.size) {
    list = list.filter((e) => e.size_bucket === filters.size);
  }
  if (filters.from) {
    list = list.filter((e) => e.timestamp >= new Date(filters.from).toISOString());
  }
  if (filters.to) {
    list = list.filter((e) => e.timestamp <= new Date(`${filters.to}T23:59:59Z`).toISOString());
  }
  if (filters.q) {
    const q = filters.q.toLowerCase();
    list = list.filter((e) =>
      `${e.evidence} ${e.source} ${e.app} ${e.classification_reason ?? ""}`
        .toLowerCase()
        .includes(q)
    );
  }
  return { events: list, total: list.length, limit: 50, offset: 0 };
}

export async function runDemoCheck(onEvent) {
  const sources = buildDemoSources().slice(0, 5);
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  onEvent({
    type: "start",
    total: sources.length,
    message: "DEMO: simulating a check (no sources contacted)…"
  });
  for (const [idx, src] of sources.entries()) {
    await sleep(250);
    onEvent({
      type: "source",
      index: idx + 1,
      total: sources.length,
      key: src.key,
      label: src.label,
      state: src.state,
      message: `Checking source ${idx + 1}/${sources.length}: ${src.label} — ${src.state}`
    });
  }
  await sleep(200);
  onEvent({ type: "compare", message: "DEMO: Comparing observations…" });
  await sleep(200);
  const done = {
    type: "complete",
    changes: 0,
    ok: 4,
    failed: 1,
    cached: false,
    message: "DEMO complete — nothing was fetched or stored."
  };
  onEvent(done);
  return done;
}
